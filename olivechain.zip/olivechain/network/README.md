# 🫒 OliveChain - Blockchain-based Olive Oil Supply Chain

## Project Overview
OliveChain is a blockchain-based supply chain management system specifically designed for tracking and managing olive oil production from harvest to delivery. This project leverages Hyperledger Fabric to create a transparent, immutable, and secure record of the entire olive oil production process.

## 🌟 Key Features
- **Batch Tracking**: Track individual batches of olives from harvest to final product
- **Quality Control**: Monitor acidity, peroxide value, and organoleptic scores
- **Supply Chain Transparency**: Monitor the entire production process
- **Analytics**: Get insights on production quality and volumes by location
- **Traceability**: Complete history of each batch's journey
- **Smart Contract Integration**: Automated business logic through chaincode

## 🏗️ Project Structure
```
olivechain/
├── chaincode/
│   └── oliveoil/
│       ├── index.js           # Main chaincode implementation
│       ├── standalone-test.js # Testing utilities
│       └── package.json       # Dependencies
├── config/                    # Network configuration
├── crypto-config/            # Cryptographic materials
├── channel-artifacts/        # Channel configuration
└── scripts/                  # Utility scripts
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- Docker and Docker Compose
- Hyperledger Fabric binaries

### Installation
1. Install dependencies:
```bash
cd chaincode/oliveoil
npm install
```

2. Start the network:
```bash
# Generate certificates
./scripts/generate-artifacts.sh

# Start the network
./scripts/start-network.sh

# Create channel
./scripts/create-channel.sh

# Deploy chaincode
./scripts/fix-channel-and-deploy.sh
```

## 💻 Chaincode Features

### Batch Management
- Create new olive batches with quality expectations
- Track batch status through the supply chain
- View complete batch history
- Update processing steps with detailed notes

### Quality Control
- Record quality metrics (acidity, peroxide value, organoleptic score)
- Validate quality parameters
- Track quality trends
- Filter batches by quality range

### Analytics
- Get production statistics by location
- Monitor quality trends
- Track processing efficiency
- Analyze batch volumes

### Available Functions
- `createBatch`: Create a new batch with quality expectations
- `getBatch`: Retrieve batch information
- `getAllBatches`: List all batches
- `updateBatchStatus`: Update batch processing status
- `updateQualityMetrics`: Record quality measurements
- `getBatchesByQualityRange`: Filter batches by quality score
- `getLocationAnalytics`: Get production statistics by location
- `addBatchProcessing`: Add processing steps with notes
- `getBatchHistory`: View complete batch history

## 🔍 Example Usage

### Creating a New Batch
```javascript
await contract.createBatch(
    'BATCH001',
    'FARMER001',
    '500',
    '2024-03-15',
    'Spain_Andalusia',
    'Picual',
    'Extra Virgin'
);
```

### Recording Quality Metrics
```javascript
await contract.updateQualityMetrics(
    'BATCH001',
    0.2,    // acidity
    10,     // peroxide value
    9       // organoleptic score
);
```

### Getting Location Analytics
```javascript
const analytics = await contract.getLocationAnalytics('Spain_Andalusia');
```

## 🧪 Testing
Run the standalone tests:
```bash
cd chaincode/oliveoil
node standalone-test.js
```

## 🔧 Network Management

### Starting the Network
```bash
./scripts/start-network.sh
```

### Creating Channel
```bash
./scripts/create-channel.sh
```

### Deploying Chaincode
```bash
./scripts/fix-channel-and-deploy.sh
```

### Testing Network
```bash
./scripts/Test-chaincode.sh
```

## 👥 Authors
Ilyas HIMIT
Fadi BAHTAT
Yassine El MOQTANIA




