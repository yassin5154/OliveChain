#!/bin/bash
# filepath: c:\Users\HP\Downloads\olivechain\olivechain\network\chaincode\oliveoil\run-demo.sh

echo "🚀 OLIVE OIL CHAINCODE DEMO"
echo "==========================="
echo ""

# Navigate to the correct directory
cd "$(dirname "$0")"

echo "📍 Current directory: $(pwd)"
echo ""

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js first."
    exit 1
fi

echo "✅ Node.js found: $(node --version)"
echo ""

# Check if the test file exists
if [ ! -f "standalone-test.js" ]; then
    echo "❌ standalone-test.js not found in current directory"
    echo "📍 Make sure you're in the chaincode/oliveoil directory"
    exit 1
fi

echo "✅ Test file found"
echo ""

echo "🧪 Running chaincode demo..."
echo "----------------------------"
echo ""

# Run the demo
node standalone-test.js

echo ""
echo "✅ Demo completed!"
echo "=================="