'use strict';

const { Contract } = require('fabric-contract-api');

class OliveOilContract extends Contract {
    
    async initLedger(ctx) {
        console.info('Olive Oil Ledger initialized');
        return 'Olive Oil Chaincode initialized successfully';
    }

    async ping(ctx) {
        return 'pong - OliveOil Chaincode is working! 🌿';
    }

    // Create a new batch of olives
    async createBatch(ctx, batchId, farmerId, quantity, harvestDate, location, oliveVariety, expectedQuality) {
        console.info(`Creating batch: ${batchId}`);
        
        // Check if batch already exists
        const existingBatch = await ctx.stub.getState(batchId);
        if (existingBatch && existingBatch.length > 0) {
            throw new Error(`Batch ${batchId} already exists`);
        }

        // Create batch object with enhanced information
        const batch = {
            batchId: batchId,
            farmerId: farmerId,
            quantity: parseInt(quantity),
            harvestDate: harvestDate,
            location: location,
            oliveVariety: oliveVariety,
            expectedQuality: expectedQuality,
            status: 'HARVESTED',
            createdAt: new Date().toISOString(),
            qualityMetrics: {
                acidity: null,
                peroxideValue: null,
                organolepticScore: null
            },
            docType: 'batch'
        };

        // Save batch to ledger
        await ctx.stub.putState(batchId, Buffer.from(JSON.stringify(batch)));
        console.info(`Batch ${batchId} created successfully`);
        
        return JSON.stringify(batch);
    }

    // Get a specific batch by ID
    async getBatch(ctx, batchId) {
        console.info(`Getting batch: ${batchId}`);
        
        const batchBytes = await ctx.stub.getState(batchId);
        if (!batchBytes || batchBytes.length === 0) {
            throw new Error(`Batch ${batchId} does not exist`);
        }

        const batch = JSON.parse(batchBytes.toString());
        return JSON.stringify(batch);
    }

    // Get all batches
    async getAllBatches(ctx) {
        console.info('Getting all batches');
        
        const iterator = await ctx.stub.getStateByRange('', '');
        const allBatches = [];

        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                const record = JSON.parse(res.value.value.toString());
                if (record.docType === 'batch') {
                    allBatches.push(record);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }

        return JSON.stringify(allBatches);
    }

    // Update quality metrics for a batch
    async updateQualityMetrics(ctx, batchId, acidity, peroxideValue, organolepticScore) {
        console.info(`Updating quality metrics for batch: ${batchId}`);
        
        const batchBytes = await ctx.stub.getState(batchId);
        if (!batchBytes || batchBytes.length === 0) {
            throw new Error(`Batch ${batchId} does not exist`);
        }

        const batch = JSON.parse(batchBytes.toString());
        
        // Validate quality metrics
        if (acidity < 0 || acidity > 1) {
            throw new Error('Acidity must be between 0 and 1');
        }
        if (peroxideValue < 0) {
            throw new Error('Peroxide value cannot be negative');
        }
        if (organolepticScore < 0 || organolepticScore > 10) {
            throw new Error('Organoleptic score must be between 0 and 10');
        }

        batch.qualityMetrics = {
            acidity: parseFloat(acidity),
            peroxideValue: parseFloat(peroxideValue),
            organolepticScore: parseInt(organolepticScore)
        };
        
        batch.status = 'QUALITY_TESTED';
        batch.updatedAt = new Date().toISOString();

        await ctx.stub.putState(batchId, Buffer.from(JSON.stringify(batch)));
        return JSON.stringify(batch);
    }

    // Get batches by quality range
    async getBatchesByQualityRange(ctx, minScore, maxScore) {
        console.info(`Getting batches with quality score between ${minScore} and ${maxScore}`);
        
        const iterator = await ctx.stub.getStateByRange('', '');
        const filteredBatches = [];

        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                const record = JSON.parse(res.value.value.toString());
                if (record.docType === 'batch' && 
                    record.qualityMetrics && 
                    record.qualityMetrics.organolepticScore >= minScore && 
                    record.qualityMetrics.organolepticScore <= maxScore) {
                    filteredBatches.push(record);
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }

        return JSON.stringify(filteredBatches);
    }

    // Get analytics for a specific location
    async getLocationAnalytics(ctx, location) {
        console.info(`Getting analytics for location: ${location}`);
        
        const iterator = await ctx.getStub().getStateByRange('', '');
        const locationBatches = [];
        let totalQuantity = 0;
        let totalQualityScore = 0;
        let batchCount = 0;

        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                const record = JSON.parse(res.value.value.toString());
                if (record.docType === 'batch' && record.location === location) {
                    locationBatches.push(record);
                    totalQuantity += record.quantity;
                    if (record.qualityMetrics && record.qualityMetrics.organolepticScore) {
                        totalQualityScore += record.qualityMetrics.organolepticScore;
                        batchCount++;
                    }
                }
            }
            if (res.done) {
                await iterator.close();
                break;
            }
        }

        const analytics = {
            location: location,
            totalBatches: locationBatches.length,
            totalQuantity: totalQuantity,
            averageQualityScore: batchCount > 0 ? totalQualityScore / batchCount : 0,
            batches: locationBatches
        };

        return JSON.stringify(analytics);
    }

    // Update batch status
    async updateBatchStatus(ctx, batchId, newStatus) {
        console.info(`Updating batch ${batchId} status to ${newStatus}`);
        
        const batchBytes = await ctx.stub.getState(batchId);
        if (!batchBytes || batchBytes.length === 0) {
            throw new Error(`Batch ${batchId} does not exist`);
        }

        const validStatuses = ['HARVESTED', 'PROCESSED', 'QUALITY_TESTED', 'PACKAGED', 'SHIPPED', 'DELIVERED'];
        if (!validStatuses.includes(newStatus)) {
            throw new Error(`Invalid status. Valid statuses: ${validStatuses.join(', ')}`);
        }

        const batch = JSON.parse(batchBytes.toString());
        batch.status = newStatus;
        batch.updatedAt = new Date().toISOString();

        await ctx.stub.putState(batchId, Buffer.from(JSON.stringify(batch)));
        return JSON.stringify(batch);
    }

    // Add processing step to batch
    async addBatchProcessing(ctx, batchId, processorId, processingDate, processingType, notes) {
        console.info(`Adding processing step to batch ${batchId}`);
        
        const batchBytes = await ctx.stub.getState(batchId);
        if (!batchBytes || batchBytes.length === 0) {
            throw new Error(`Batch ${batchId} does not exist`);
        }

        const batch = JSON.parse(batchBytes.toString());
        
        if (!batch.processingHistory) {
            batch.processingHistory = [];
        }

        batch.processingHistory.push({
            processorId,
            processingDate,
            processingType,
            notes,
            timestamp: new Date().toISOString()
        });

        batch.status = processingType;
        batch.updatedAt = new Date().toISOString();

        await ctx.stub.putState(batchId, Buffer.from(JSON.stringify(batch)));
        return JSON.stringify(batch);
    }

    // Get batch history
    async getBatchHistory(ctx, batchId) {
        console.info(`Getting history for batch ${batchId}`);
        
        const batchBytes = await ctx.stub.getState(batchId);
        if (!batchBytes || batchBytes.length === 0) {
            throw new Error(`Batch ${batchId} does not exist`);
        }

        const batch = JSON.parse(batchBytes.toString());
        const history = {
            batchId: batch.batchId,
            createdAt: batch.createdAt,
            status: batch.status,
            processingHistory: batch.processingHistory || [],
            qualityMetrics: batch.qualityMetrics || {},
            lastUpdate: batch.updatedAt || batch.createdAt
        };

        return JSON.stringify(history);
    }
}

module.exports = OliveOilContract;