#!/bin/bash

echo "🔧 DIAGNOSTIC RÉSEAU HYPERLEDGER FABRIC"
echo "======================================="
date

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
ORDERER_ADDRESS="orderer.oliveoil.com:7050"
ORDERER_TLS_HOSTNAME="orderer.orderer.oliveoil.com"
CHANNEL_NAME="oliveoilchannel"

PEERS=(
    "peer0.farmer.oliveoil.com:7051"
    "peer0.distributor.oliveoil.com:10051"
    "peer0.mill.oliveoil.com:9051"
    "peer0.retailer.oliveoil.com:11051"
    "peer0.collector.oliveoil.com:8051"
)

ORGS=("farmer" "distributor" "mill" "retailer" "collector")

echo -e "\n${YELLOW}=== ÉTAPE 1: VÉRIFICATION CONNECTIVITÉ RÉSEAU ===${NC}"

# Test ping des hostnames
for peer in "${PEERS[@]}"; do
    hostname=$(echo $peer | cut -d: -f1)
    port=$(echo $peer | cut -d: -f2)
    
    echo -n "🌐 Test connectivité $hostname:$port ... "
    if timeout 5 bash -c "</dev/tcp/$hostname/$port" 2>/dev/null; then
        echo -e "${GREEN}✅ OK${NC}"
    else
        echo -e "${RED}❌ ÉCHEC${NC}"
        echo "   Vérifiez que le peer est démarré et accessible"
    fi
done

echo -e "\n${YELLOW}=== ÉTAPE 2: VÉRIFICATION CERTIFICATS TLS ===${NC}"

# Fonction pour vérifier un certificat
check_cert() {
    local peer_address=$1
    local org=$2
    local cert_path="/mnt/c/Users/HP/Downloads/olivechain/olivechain/network/organizations/peerOrganizations/${org}.oliveoil.com/peers/peer0.${org}.oliveoil.com/tls/server.crt"
    
    echo "🔍 Vérification certificat $peer_address"
    
    if [ -f "$cert_path" ]; then
        echo "   📁 Certificat trouvé: $cert_path"
        
        # Extraire les SANs (Subject Alternative Names)
        sans=$(openssl x509 -in "$cert_path" -text -noout 2>/dev/null | grep -A1 "Subject Alternative Name" | tail -1 | sed 's/DNS://g' | tr ',' '\n' | xargs)
        
        if [ ! -z "$sans" ]; then
            echo "   🏷️  SANs: $sans"
            
            # Vérifier si l'adresse correspond aux SANs
            hostname=$(echo $peer_address | cut -d: -f1)
            if echo "$sans" | grep -q "$hostname"; then
                echo -e "   ${GREEN}✅ Hostname TLS valide${NC}"
            else
                echo -e "   ${RED}❌ Hostname TLS invalide${NC}"
                echo "   💡 Utiliser --tlsRootCertFiles et vérifier les SANs"
            fi
        else
            echo -e "   ${YELLOW}⚠️  Impossible de lire les SANs${NC}"
        fi
    else
        echo -e "   ${RED}❌ Certificat non trouvé: $cert_path${NC}"
    fi
    echo
}

# Vérifier les certificats de tous les peers
for i in "${!PEERS[@]}"; do
    check_cert "${PEERS[$i]}" "${ORGS[$i]}"
done

echo -e "\n${YELLOW}=== ÉTAPE 3: VÉRIFICATION STATUT DES CONTENEURS ===${NC}"

echo "🐳 Statut des conteneurs Docker:"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "(peer|orderer|ca)"

echo -e "\n${YELLOW}=== ÉTAPE 4: TEST COMMANDES FABRIC BASIQUES ===${NC}"

# Test basique avec l'orderer
echo "🧪 Test fetch config block avec orderer:"
export FABRIC_CFG_PATH=/mnt/c/Users/HP/Downloads/olivechain/olivechain/network/config
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="FarmerMSP"
export CORE_PEER_TLS_ROOTCERT_FILE=/mnt/c/Users/HP/Downloads/olivechain/olivechain/network/organizations/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/mnt/c/Users/HP/Downloads/olivechain/olivechain/network/organizations/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

timeout 10 peer channel fetch config \
    -c $CHANNEL_NAME \
    -o $ORDERER_ADDRESS \
    --ordererTLSHostnameOverride $ORDERER_TLS_HOSTNAME \
    --tls --cafile /mnt/c/Users/HP/Downloads/olivechain/olivechain/network/organizations/ordererOrganizations/oliveoil.com/orderers/orderer.oliveoil.com/msp/tlscacerts/tlsca.oliveoil.com-cert.pem

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Communication orderer OK${NC}"
else
    echo -e "${RED}❌ Problème communication orderer${NC}"
fi

echo -e "\n${YELLOW}=== ÉTAPE 5: RECOMMANDATIONS ===${NC}"

echo "🎯 Actions recommandées:"
echo "1. 🔄 Redémarrer les conteneurs problématiques"
echo "2. 🌐 Vérifier les ports et pare-feu"  
echo "3. ⏱️  Augmenter les timeouts dans core.yaml"
echo "4. 🔧 Utiliser les bonnes options TLS"
echo "5. 📋 Vérifier les logs des conteneurs"

echo -e "\n🔧 Commandes utiles:"
echo "# Logs d'un peer:"
echo "docker logs peer0.farmer.oliveoil.com"
echo ""
echo "# Redémarrer un peer:"
echo "docker restart peer0.farmer.oliveoil.com"
echo ""
echo "# Vérifier les processus d'écoute:"
echo "docker exec peer0.farmer.oliveoil.com netstat -tlnp"

echo -e "\n${GREEN}DIAGNOSTIC TERMINÉ${NC}"
echo "======================================="
