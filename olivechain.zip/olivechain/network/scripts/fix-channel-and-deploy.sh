#!/bin/bash

echo "🔧 CORRECTION CANAL ET DÉPLOIEMENT COMPLET"
echo "=========================================="

# Configuration
CHANNEL_NAME="oliveoilchannel"
CHAINCODE_NAME="oliveoil"
CHAINCODE_VERSION="1.0"
SEQUENCE="1"

echo "🔍 Étape 1: Diagnostic du canal..."

# Vérifier qui a rejoint le canal
echo "📋 Peers ayant rejoint le canal:"
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer channel list
"

echo ""
echo "🤝 Étape 2: Faire rejoindre tous les peers au canal..."

# Liste des organisations
organizations=(
    "collector:CollectorMSP:peer0.collector.oliveoil.com:8051"
    "mill:MillMSP:peer0.mill.oliveoil.com:9051"
    "distributor:DistributorMSP:peer0.distributor.oliveoil.com:10051"
    "retailer:RetailerMSP:peer0.retailer.oliveoil.com:11051"
)

# Vérifier si le fichier de canal existe
if [ ! -f "${CHANNEL_NAME}.block" ]; then
    echo "📁 Fichier de canal manquant, copie depuis CLI..."
    docker cp cli:/opt/gopath/src/github.com/hyperledger/fabric/peer/${CHANNEL_NAME}.block . 2>/dev/null || echo "⚠️ Fichier bloc non trouvé dans CLI"
fi

# Faire rejoindre chaque organisation au canal
for org_info in "${organizations[@]}"; do
    IFS=':' read -r org_name msp_id peer_address port <<< "$org_info"
    
    echo "🤝 Ajout de $org_name au canal..."
    
    # Copier le fichier de canal si nécessaire
    docker exec cli bash -c "
    export CORE_PEER_LOCALMSPID=$msp_id
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/${org_name}.oliveoil.com/peers/peer0.${org_name}.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/${org_name}.oliveoil.com/users/Admin@${org_name}.oliveoil.com/msp
    export CORE_PEER_ADDRESS=$peer_address:$port
    
    # Joindre le canal
    peer channel join -b ${CHANNEL_NAME}.block
    
    # Vérifier la jointure
    peer channel list
    " && echo "  ✅ $org_name rejoint le canal" || echo "  ❌ $org_name échec de jointure"
    
    sleep 5
done

echo ""
echo "⏳ Attente propagation du canal (30s)..."
sleep 30

echo ""
echo "📋 Vérification des jointures..."
for org_info in "${organizations[@]}"; do
    IFS=':' read -r org_name msp_id peer_address port <<< "$org_info"
    
    echo "Vérification $org_name:"
    docker exec cli bash -c "
    export CORE_PEER_LOCALMSPID=$msp_id
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/${org_name}.oliveoil.com/peers/peer0.${org_name}.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/${org_name}.oliveoil.com/users/Admin@${org_name}.oliveoil.com/msp
    export CORE_PEER_ADDRESS=$peer_address:$port
    
    peer channel list | grep $CHANNEL_NAME
    " && echo "  ✅ $org_name sur le canal" || echo "  ❌ $org_name pas sur le canal"
done

echo ""
echo "🔍 Étape 3: Récupération Package ID..."

# Obtenir Package ID
PACKAGE_ID=$(docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[] | select(.label | contains(\"oliveoil\")) | .package_id' | head -1
")

echo "📋 Package ID: $PACKAGE_ID"

if [ -z "$PACKAGE_ID" ]; then
    echo "❌ Package ID non trouvé"
    exit 1
fi

echo ""
echo "👍 Étape 4: Approbations avec canal correct..."

# Approuver avec Farmer
echo "👨‍🌾 Approbation FarmerMSP..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

timeout 120 peer lifecycle chaincode approveformyorg \
    -o orderer.oliveoil.com:7050 \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --channelID $CHANNEL_NAME \
    --name $CHAINCODE_NAME \
    --version $CHAINCODE_VERSION \
    --package-id $PACKAGE_ID \
    --sequence $SEQUENCE
" && echo "✅ Farmer approuvé" || echo "❌ Farmer échec"

sleep 10

# Approuver avec Collector
echo "🚛 Approbation CollectorMSP..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=CollectorMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/collector.oliveoil.com/peers/peer0.collector.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/collector.oliveoil.com/users/Admin@collector.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.collector.oliveoil.com:8051

timeout 120 peer lifecycle chaincode approveformyorg \
    -o orderer.oliveoil.com:7050 \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --channelID $CHANNEL_NAME \
    --name $CHAINCODE_NAME \
    --version $CHAINCODE_VERSION \
    --package-id $PACKAGE_ID \
    --sequence $SEQUENCE
" && echo "✅ Collector approuvé" || echo "❌ Collector échec"

sleep 10

# Approuver avec Mill
echo "🏭 Approbation MillMSP..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=MillMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/mill.oliveoil.com/peers/peer0.mill.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/mill.oliveoil.com/users/Admin@mill.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.mill.oliveoil.com:9051

timeout 120 peer lifecycle chaincode approveformyorg \
    -o orderer.oliveoil.com:7050 \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --channelID $CHANNEL_NAME \
    --name $CHAINCODE_NAME \
    --version $CHAINCODE_VERSION \
    --package-id $PACKAGE_ID \
    --sequence $SEQUENCE
" && echo "✅ Mill approuvé" || echo "❌ Mill échec"

sleep 15

echo ""
echo "📊 Vérification des approbations..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer lifecycle chaincode checkcommitreadiness \
    --channelID $CHANNEL_NAME \
    --name $CHAINCODE_NAME \
    --version $CHAINCODE_VERSION \
    --sequence $SEQUENCE
"

echo ""
echo "🚀 Étape 5: Commit avec consensus..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

timeout 300 peer lifecycle chaincode commit \
    -o orderer.oliveoil.com:7050 \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --channelID $CHANNEL_NAME \
    --name $CHAINCODE_NAME \
    --version $CHAINCODE_VERSION \
    --sequence $SEQUENCE \
    --peerAddresses peer0.farmer.oliveoil.com:7051 \
    --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt \
    --peerAddresses peer0.collector.oliveoil.com:8051 \
    --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/collector.oliveoil.com/peers/peer0.collector.oliveoil.com/tls/ca.crt \
    --peerAddresses peer0.mill.oliveoil.com:9051 \
    --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/mill.oliveoil.com/peers/peer0.mill.oliveoil.com/tls/ca.crt
"

echo ""
echo "⏳ Attente commit (30s)..."
sleep 30

echo "🔧 Étape 6: Initialisation..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

timeout 120 peer chaincode invoke \
    -o orderer.oliveoil.com:7050 \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    -C $CHANNEL_NAME \
    -n $CHAINCODE_NAME \
    --peerAddresses peer0.farmer.oliveoil.com:7051 \
    --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt \
    -c '{\"function\":\"initLedger\",\"Args\":[]}'
"

echo ""
echo "⏳ Attente initialisation (15s)..."
sleep 15

echo "🧪 Étape 7: Tests complets..."

echo "Test ping:"
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{\"function\":\"ping\",\"Args\":[]}'
"

echo ""
echo "Test getAllOliveOils:"
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer chaincode query -C $CHANNEL_NAME -n $CHAINCODE_NAME -c '{\"function\":\"getAllOliveOils\",\"Args\":[]}'
"

echo ""
echo "📋 Chaincodes committés:"
docker exec cli peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME

echo ""
echo "✅ DÉPLOIEMENT AVEC CANAL CORRIGÉ TERMINÉ!"
echo ""
echo "🎯 Résumé des corrections apportées:"
echo "   1. ✅ Tous les peers ont rejoint le canal"
echo "   2. ✅ Approbations par plusieurs organisations"
echo "   3. ✅ Commit avec consensus multi-organisations"
echo "   4. ✅ TLS hostname override corrigé"
echo ""
echo "🧪 Commandes de test rapides:"
echo '   docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode query -C oliveoilchannel -n oliveoil -c '"'"'{"function":"ping","Args":[]}'"'"'"'
echo ""
echo '   docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode invoke -C oliveoilchannel -n oliveoil -c '"'"'{"function":"createOliveOil","Args":["OO001","Extra Virgin","Spain","2024"]}'"'"' -o orderer.oliveoil.com:7050 --ordererTLSHostnameOverride orderer.orderer.oliveoil.com --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem"'

echo ""
echo "======================================"
date