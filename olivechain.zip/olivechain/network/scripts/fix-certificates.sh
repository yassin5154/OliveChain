#!/bin/bash
set -e

echo "🔧 CORRECTION DES CERTIFICATS TLS HYPERLEDGER FABRIC"
echo "=================================================="
date

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_step() {
    echo -e "\n${YELLOW}=== $1 ===${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Configuration
CHANNEL_NAME="oliveoilchannel"
CHAINCODE_NAME="oliveoil"
CHAINCODE_VERSION="2.1"

# Aller dans le répertoire network
cd "$(dirname "$0")/.."

print_step "ÉTAPE 1: ARRÊT COMPLET DU RÉSEAU"
echo "🛑 Arrêt de tous les conteneurs..."

docker-compose -f docker/docker-compose.yaml down -v --remove-orphans
docker system prune -af --volumes
docker network prune -f

print_success "Réseau arrêté"

print_step "ÉTAPE 2: SUPPRESSION DES ANCIENS CERTIFICATS"
echo "🗑️ Suppression des certificats corrompus..."

# Supprimer complètement les anciens certificats
rm -rf crypto-config/
rm -rf channel-artifacts/

print_success "Anciens certificats supprimés"

print_step "ÉTAPE 3: GÉNÉRATION DE NOUVEAUX CERTIFICATS"
echo "🔐 Génération de nouveaux certificats avec cryptogen..."

# Créer les répertoires
mkdir -p crypto-config
mkdir -p channel-artifacts

# Générer les certificats avec cryptogen (dans un conteneur temporaire)
echo "📝 Génération des certificats organisationnels..."

docker run --rm \
    -v $(pwd):/work \
    -w /work \
    hyperledger/fabric-tools:2.5 \
    cryptogen generate --config=config/crypto-config.yaml --output=crypto-config

if [ ! -d "crypto-config/peerOrganizations" ]; then
    print_error "Échec de la génération des certificats"
    exit 1
fi

print_success "Certificats générés avec cryptogen"

print_step "ÉTAPE 3.5: CORRECTION STRUCTURE MSP ORDERER"
echo "🔧 Correction de la structure MSP de l'orderer..."

# Vérifier et corriger la structure MSP de l'orderer
ORDERER_MSP_DIR="crypto-config/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp"

if [ -d "$ORDERER_MSP_DIR" ]; then
    echo "🔍 Vérification structure MSP orderer..."
    
    # Créer les répertoires manquants si nécessaire
    mkdir -p "$ORDERER_MSP_DIR/signcerts"
    mkdir -p "$ORDERER_MSP_DIR/keystore"
    mkdir -p "$ORDERER_MSP_DIR/cacerts"
    mkdir -p "$ORDERER_MSP_DIR/tlscacerts"
    mkdir -p "$ORDERER_MSP_DIR/admincerts"
    
    # Copier le certificat signé vers signcerts si il n'existe pas
    if [ ! -f "$ORDERER_MSP_DIR/signcerts/orderer.orderer.oliveoil.com-cert.pem" ]; then
        if [ -f "crypto-config/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/signcerts/cert.pem" ]; then
            cp "$ORDERER_MSP_DIR/signcerts/cert.pem" "$ORDERER_MSP_DIR/signcerts/orderer.orderer.oliveoil.com-cert.pem"
        elif [ -f "crypto-config/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/signcerts/"*.pem ]; then
            # S'assurer qu'il y a au moins un fichier .pem dans signcerts
            echo "✅ Certificat signé trouvé dans signcerts"
        else
            print_error "Aucun certificat signé trouvé pour l'orderer"
            echo "📋 Contenu du répertoire MSP orderer:"
            ls -la "$ORDERER_MSP_DIR/"
            exit 1
        fi
    fi
    
    # Vérifier la clé privée
    if [ ! -f "$ORDERER_MSP_DIR/keystore/"*_sk ]; then
        print_error "Clé privée manquante pour l'orderer"
        echo "📋 Contenu keystore:"
        ls -la "$ORDERER_MSP_DIR/keystore/" || echo "Répertoire keystore vide"
        exit 1
    fi
    
    print_success "Structure MSP orderer corrigée"
    
    echo "📋 Structure MSP orderer finale:"
    echo "   signcerts: $(ls -1 $ORDERER_MSP_DIR/signcerts/ | wc -l) fichier(s)"
    echo "   keystore: $(ls -1 $ORDERER_MSP_DIR/keystore/ | wc -l) fichier(s)"
    echo "   cacerts: $(ls -1 $ORDERER_MSP_DIR/cacerts/ | wc -l) fichier(s)"
    echo "   tlscacerts: $(ls -1 $ORDERER_MSP_DIR/tlscacerts/ | wc -l) fichier(s)"
    
else
    print_error "Répertoire MSP orderer introuvable: $ORDERER_MSP_DIR"
    exit 1
fi

print_step "ÉTAPE 4: GÉNÉRATION DU GENESIS BLOCK"
echo "🏗️ Génération du genesis block..."

# Variables d'environnement pour configtxgen
export FABRIC_CFG_PATH=$(pwd)/config

# Générer le genesis block
docker run --rm \
    -v $(pwd):/work \
    -w /work \
    -e FABRIC_CFG_PATH=/work/config \
    hyperledger/fabric-tools:2.5 \
    configtxgen -profile OliveOilOrdererGenesis -channelID system-channel -outputBlock channel-artifacts/genesis.block

if [ ! -f "channel-artifacts/genesis.block" ]; then
    print_error "Échec de la génération du genesis block"
    exit 1
fi

print_success "Genesis block généré"

print_step "ÉTAPE 5: GÉNÉRATION DU CHANNEL TX"
echo "📄 Génération de la transaction de canal..."

docker run --rm \
    -v $(pwd):/work \
    -w /work \
    -e FABRIC_CFG_PATH=/work/config \
    hyperledger/fabric-tools:2.5 \
    configtxgen -profile OliveOilChannel -outputCreateChannelTx channel-artifacts/channel.tx -channelID $CHANNEL_NAME

if [ ! -f "channel-artifacts/channel.tx" ]; then
    print_error "Échec de la génération du channel.tx"
    exit 1
fi

print_success "Channel transaction générée"

print_step "ÉTAPE 6: VÉRIFICATION DES CERTIFICATS"
echo "🔍 Vérification de la validité des certificats..."

# Vérifier les certificats de l'orderer
ORDERER_CERT="crypto-config/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/tls/server.crt"

if [ -f "$ORDERER_CERT" ]; then
    echo "📋 Informations du certificat orderer:"
    openssl x509 -in "$ORDERER_CERT" -text -noout | grep -A1 "Subject\|DNS\|IP"
    print_success "Certificat orderer valide"
else
    print_error "Certificat orderer manquant: $ORDERER_CERT"
    exit 1
fi

# Vérifier les certificats des peers
for org in farmer collector mill distributor retailer; do
    PEER_CERT="crypto-config/peerOrganizations/${org}.oliveoil.com/peers/peer0.${org}.oliveoil.com/tls/server.crt"
    if [ -f "$PEER_CERT" ]; then
        print_info "Certificat peer ${org} ✅"
    else
        print_error "Certificat peer ${org} manquant: $PEER_CERT"
        exit 1
    fi
done

print_success "Tous les certificats sont valides"

print_step "ÉTAPE 7: VÉRIFICATION FINALE MSP AVANT DÉMARRAGE"
echo "🔍 Vérification finale de la structure MSP..."

# Vérification finale de l'orderer MSP
echo "📋 Vérification MSP orderer:"
if [ -f "$ORDERER_MSP_DIR/signcerts/"*.pem ]; then
    echo "   ✅ signcerts: OK"
else
    print_error "signcerts manquant"
    exit 1
fi

if [ -f "$ORDERER_MSP_DIR/keystore/"*_sk ]; then
    echo "   ✅ keystore: OK"
else
    print_error "keystore manquant"
    exit 1
fi

if [ -f "$ORDERER_MSP_DIR/cacerts/"*.pem ]; then
    echo "   ✅ cacerts: OK"
else
    print_error "cacerts manquant"
    exit 1
fi

print_success "Structure MSP validée"

print_step "ÉTAPE 8: DÉMARRAGE DU RÉSEAU AVEC NOUVEAUX CERTIFICATS"
echo "🚀 Démarrage du réseau avec les nouveaux certificats..."

# Démarrer les conteneurs
docker-compose -f docker/docker-compose.yaml up -d

echo "⏳ Attente de la stabilisation (60 secondes)..."
sleep 60

# Vérifier le statut
echo "📊 Statut des conteneurs:"
docker ps --format "table {{.Names}}\t{{.Status}}"

# Vérifier spécifiquement l'orderer
echo ""
echo "🔍 Vérification spécifique de l'orderer..."
if docker ps | grep -q "orderer.oliveoil.com.*Up"; then
    print_success "Orderer démarré avec succès"
    
    # Vérifier les logs pour s'assurer qu'il n'y a pas d'erreurs MSP
    echo "📋 Derniers logs de l'orderer:"
    docker logs orderer.oliveoil.com --tail 5
    
else
    print_error "Problème avec le démarrage de l'orderer"
    echo "📋 Logs d'erreur de l'orderer:"
    docker logs orderer.oliveoil.com --tail 20
    exit 1
fi

print_step "ÉTAPE 9: VÉRIFICATION DE LA CONNECTIVITÉ TLS"
echo "🔗 Test de la connectivité TLS..."

# Attendre un peu plus pour que l'orderer soit complètement prêt
sleep 20

# Tester la connectivité orderer depuis le CLI
echo "🧪 Test de connectivité avec l'orderer..."

if timeout 30 docker exec cli openssl s_client -connect orderer.oliveoil.com:7050 -servername orderer.orderer.oliveoil.com -verify_return_error -CAfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem < /dev/null 2>/dev/null; then
    print_success "Connectivité TLS orderer OK"
else
    print_error "Problème de connectivité TLS avec l'orderer"
    
    echo ""
    echo "🔍 Diagnostic supplémentaire:"
    echo "   Logs de l'orderer:"
    docker logs orderer.oliveoil.com --tail 10
fi

print_step "ÉTAPE 10: CRÉATION DU CANAL AVEC NOUVEAUX CERTIFICATS"
echo "📝 Création du canal avec les nouveaux certificats..."

# Attendre un peu plus pour la stabilisation
sleep 30

if timeout 60 docker exec cli peer channel create \
    -o orderer.oliveoil.com:7050 \
    -c $CHANNEL_NAME \
    -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com; then
    
    print_success "Canal créé avec succès!"
    
    echo ""
    echo "🎉 CERTIFICATS CORRIGÉS AVEC SUCCÈS!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "✅ Nouveaux certificats TLS générés et validés"
    echo "✅ Structure MSP orderer corrigée"
    echo "✅ Connectivité orderer restaurée"
    echo "✅ Canal créé avec succès"
    echo ""
    echo "🔄 Vous pouvez maintenant relancer le déploiement complet:"
    echo "   ./scripts/full-restart-and-deploy.sh"
    
else
    print_error "Échec de la création du canal"
    
    echo ""
    echo "🔧 Commandes de diagnostic:"
    echo "   docker logs orderer.oliveoil.com"
    echo "   docker logs cli"
    echo "   docker exec cli ping orderer.oliveoil.com"
    
    echo ""
    echo "💡 Structure MSP à vérifier manuellement:"
    echo "   ls -la crypto-config/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/"
fi

echo ""
echo "=================================================="
date