#!/bin/bash

echo "📦 Génération des artefacts..."

# Clean up existing artifacts
rm -rf crypto-config
rm -rf channel-artifacts
mkdir -p channel-artifacts

# Generate certificates
cryptogen generate --config=./config/crypto-config.yaml --output=crypto-config

# Generate genesis block
configtxgen -profile OliveOilOrdererGenesis \
    -channelID system-channel \
    -outputBlock ./channel-artifacts/genesis.block \
    -configPath ./config

# Generate channel transaction
configtxgen -profile OliveOilChannel \
    -outputCreateChannelTx ./channel-artifacts/channel.tx \
    -channelID oliveoilchannel \
    -configPath ./config