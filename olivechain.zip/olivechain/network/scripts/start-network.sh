#!/bin/bash
set -e

echo "🚀 DÉMARRAGE COMPLET DU RÉSEAU HYPERLEDGER FABRIC"
echo "================================================="
date

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_step() {
    echo -e "\n${YELLOW}=== $1 ===${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Change to the network directory to ensure correct paths
cd "$(dirname "$0")/.."

print_step "ÉTAPE 1: ARRÊT COMPLET DU RÉSEAU EXISTANT"
echo "🛑 Arrêt de tous les conteneurs et nettoyage..."

# Arrêter et supprimer tous les conteneurs liés au réseau
echo "📦 Arrêt des conteneurs Fabric..."
docker-compose -f docker/docker-compose.yaml down -v --remove-orphans 2>/dev/null || true

# Supprimer les conteneurs orphelins spécifiques s'ils existent
echo "🧹 Nettoyage des conteneurs orphelins..."
for container in cli orderer.oliveoil.com peer0.farmer.oliveoil.com peer0.collector.oliveoil.com peer0.mill.oliveoil.com peer0.distributor.oliveoil.com peer0.retailer.oliveoil.com; do
    if docker ps -a --format '{{.Names}}' | grep -q "^${container}$"; then
        echo "   Suppression: $container"
        docker rm -f $container 2>/dev/null || true
    fi
done

# Supprimer les volumes Docker liés
echo "🗄️ Suppression des volumes Docker..."
docker volume prune -f

# Supprimer les réseaux Docker orphelins
echo "🌐 Nettoyage des réseaux Docker..."
docker network rm docker_fabric_network 2>/dev/null || true
docker network prune -f

print_success "Réseau arrêté et nettoyé"

print_step "ÉTAPE 2: VÉRIFICATION DES PRÉREQUIS"
echo "🔍 Vérification des fichiers nécessaires..."

# Vérifier la présence du docker-compose
if [ ! -f "docker/docker-compose.yaml" ]; then
    print_error "Fichier docker-compose.yaml introuvable dans docker/"
    exit 1
fi

# Vérifier les configurations
if [ ! -f "config/configtx.yaml" ]; then
    print_error "Fichier configtx.yaml introuvable dans config/"
    exit 1
fi

if [ ! -f "config/crypto-config.yaml" ]; then
    print_error "Fichier crypto-config.yaml introuvable dans config/"
    exit 1
fi

print_success "Fichiers de configuration trouvés"

print_step "ÉTAPE 3: PRÉPARATION DES RÉPERTOIRES"
echo "📁 Création des répertoires nécessaires..."

# Créer les répertoires requis
mkdir -p channel-artifacts
mkdir -p crypto-config

print_success "Répertoires créés"

print_step "ÉTAPE 4: GÉNÉRATION COMPLÈTE DES CERTIFICATS ET ARTEFACTS"
echo "🔐 Régénération complète des certificats et artefacts..."

# TOUJOURS régénérer les certificats pour éviter les problèmes de structure
echo "🗑️ Suppression des anciens certificats..."
rm -rf crypto-config/

echo "📝 Génération des nouveaux certificats avec cryptogen..."

# Générer les certificats avec cryptogen
if ! docker run --rm \
    -v $(pwd):/work \
    -w /work \
    hyperledger/fabric-tools:2.5 \
    cryptogen generate --config=config/crypto-config.yaml --output=crypto-config; then
    print_error "Échec de la génération des certificats"
    exit 1
fi

print_success "Certificats générés"

# Vérifier et corriger la structure des certificats
echo "🔧 Vérification et correction de la structure des certificats..."

# Vérifier la structure OrdererOrg
ORDERER_MSP_DIR="crypto-config/ordererOrganizations/orderer.oliveoil.com/msp"
if [ ! -d "$ORDERER_MSP_DIR/cacerts" ]; then
    print_error "Répertoire cacerts manquant pour OrdererOrg: $ORDERER_MSP_DIR/cacerts"
    
    echo "📋 Structure actuelle de $ORDERER_MSP_DIR:"
    ls -la "$ORDERER_MSP_DIR/" || echo "Répertoire MSP inexistant"
    
    echo "📋 Structure complète crypto-config/ordererOrganizations:"
    find crypto-config/ordererOrganizations -type d -name "*cacerts*" || echo "Aucun répertoire cacerts trouvé"
    
    exit 1
fi

# Vérifier chaque organisation peer
for org in farmer collector mill distributor retailer; do
    PEER_MSP_DIR="crypto-config/peerOrganizations/${org}.oliveoil.com/msp"
    if [ ! -d "$PEER_MSP_DIR/cacerts" ]; then
        print_error "Répertoire cacerts manquant pour ${org}: $PEER_MSP_DIR/cacerts"
        exit 1
    fi
    print_info "✅ Structure MSP $org validée"
done

print_success "Structure des certificats validée"

# TOUJOURS régénérer les artefacts pour correspondre aux nouveaux certificats
echo "🗑️ Suppression des anciens artefacts..."
rm -rf channel-artifacts/*

echo "🏗️ Génération des artefacts de canal..."

export FABRIC_CFG_PATH=$(pwd)/config

# Générer le genesis block
echo "📦 Génération du genesis block..."
if ! docker run --rm \
    -v $(pwd):/work \
    -w /work \
    -e FABRIC_CFG_PATH=/work/config \
    hyperledger/fabric-tools:2.5 \
    configtxgen -profile OliveOilOrdererGenesis -channelID system-channel -outputBlock channel-artifacts/genesis.block; then
    
    print_error "Échec de la génération du genesis block"
    
    echo ""
    echo "🔍 DIAGNOSTIC DE LA CONFIGURATION:"
    echo "   Structure crypto-config/ordererOrganizations:"
    find crypto-config/ordererOrganizations -name "*cacerts*" -type d
    echo ""
    echo "   Contenu du répertoire cacerts OrdererOrg:"
    ls -la crypto-config/ordererOrganizations/orderer.oliveoil.com/msp/cacerts/ || echo "Répertoire vide ou inexistant"
    echo ""
    echo "   Test de la configuration configtx.yaml:"
    docker run --rm \
        -v $(pwd):/work \
        -w /work \
        -e FABRIC_CFG_PATH=/work/config \
        hyperledger/fabric-tools:2.5 \
        configtxgen -inspectBlock /dev/null 2>&1 | head -20
    
    exit 1
fi

# Générer la transaction de canal
echo "📄 Génération de la transaction de canal..."
if ! docker run --rm \
    -v $(pwd):/work \
    -w /work \
    -e FABRIC_CFG_PATH=/work/config \
    hyperledger/fabric-tools:2.5 \
    configtxgen -profile OliveOilChannel -outputCreateChannelTx channel-artifacts/channel.tx -channelID oliveoilchannel; then
    print_error "Échec de la génération de la transaction de canal"
    exit 1
fi

print_success "Artefacts de canal générés"

print_step "ÉTAPE 5: VÉRIFICATION DES ARTEFACTS GÉNÉRÉS"
echo "📊 Vérification des fichiers générés..."

# Vérifier les fichiers générés
if [ -f "channel-artifacts/genesis.block" ]; then
    print_info "✅ Genesis block créé ($(du -h channel-artifacts/genesis.block | cut -f1))"
else
    print_error "Genesis block manquant"
    exit 1
fi

if [ -f "channel-artifacts/channel.tx" ]; then
    print_info "✅ Transaction de canal créée ($(du -h channel-artifacts/channel.tx | cut -f1))"
else
    print_error "Transaction de canal manquante"
    exit 1
fi

print_success "Tous les artefacts sont prêts"

print_step "ÉTAPE 6: DÉMARRAGE DES CONTENEURS"
echo "🚀 Démarrage des conteneurs Hyperledger Fabric..."

# Démarrer tous les conteneurs
if ! docker-compose -f docker/docker-compose.yaml up -d; then
    print_error "Échec du démarrage des conteneurs"
    echo ""
    echo "🔧 Commandes de diagnostic:"
    echo "   docker-compose -f docker/docker-compose.yaml logs"
    echo "   docker ps -a"
    exit 1
fi

print_success "Conteneurs démarrés"

print_step "ÉTAPE 7: ATTENTE DE LA STABILISATION"
echo "⏳ Attente de la stabilisation du réseau (60 secondes)..."
sleep 60

print_step "ÉTAPE 8: VÉRIFICATION DU STATUT"
echo "📊 Vérification du statut des conteneurs..."

# Vérifier le statut des conteneurs
echo "🐳 Statut des conteneurs:"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "(peer|orderer|cli)"

# Vérifier spécifiquement l'orderer
echo ""
echo "🔍 Vérification de l'orderer..."
if docker ps | grep -q "orderer.oliveoil.com.*Up"; then
    print_success "Orderer en cours d'exécution"
    
    # Vérifier les logs de l'orderer
    echo "📋 Derniers logs de l'orderer:"
    docker logs orderer.oliveoil.com --tail 10
    
    # Vérifier si l'orderer est prêt à servir
    if docker logs orderer.oliveoil.com 2>&1 | grep -q "Beginning to serve requests"; then
        print_success "Orderer prêt à servir les requêtes"
    else
        print_error "Orderer pas encore prêt"
        echo "⏳ Attente supplémentaire de 30 secondes..."
        sleep 30
    fi
else
    print_error "Problème avec l'orderer"
    echo "📋 Logs d'erreur de l'orderer:"
    docker logs orderer.oliveoil.com
    exit 1
fi

# Vérifier les peers
echo ""
echo "🔍 Vérification des peers..."
peer_count=0
for peer in peer0.farmer.oliveoil.com peer0.collector.oliveoil.com peer0.mill.oliveoil.com peer0.distributor.oliveoil.com peer0.retailer.oliveoil.com; do
    if docker ps | grep -q "${peer}.*Up"; then
        print_info "✅ $peer en cours d'exécution"
        ((peer_count++))
    else
        print_error "❌ $peer problématique"
        docker logs $peer --tail 5
    fi
done

if [ $peer_count -ge 3 ]; then
    print_success "Suffisamment de peers actifs ($peer_count/5)"
else
    print_error "Pas assez de peers actifs ($peer_count/5)"
    exit 1
fi

# Vérifier le CLI
echo ""
echo "🔍 Vérification du CLI..."
if docker ps | grep -q "cli.*Up"; then
    print_success "CLI en cours d'exécution"
else
    print_error "Problème avec le CLI"
    docker logs cli --tail 10
    exit 1
fi

print_step "ÉTAPE 9: CRÉATION ET JOINTURE DU CANAL"
echo "📝 Création manuelle du canal..."

# Attendre un peu plus pour s'assurer que tout est stabilisé
sleep 20

# Créer le canal directement (plus fiable que d'appeler un autre script)
echo "🏗️ Création du canal oliveoilchannel..."
if timeout 60 docker exec cli peer channel create \
    -o orderer.oliveoil.com:7050 \
    -c oliveoilchannel \
    -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com; then
    
    print_success "Canal créé avec succès"
    
    # Joindre le peer farmer au canal (CLI est configuré pour farmer par défaut)
    echo "🤝 Jointure du peer farmer au canal..."
    if docker exec cli peer channel join -b oliveoilchannel.block; then
        print_success "Farmer joint au canal"
    else
        print_error "Échec de la jointure du farmer"
    fi
    
else
    print_error "Échec de la création du canal"
    echo ""
    echo "🔧 Diagnostic:"
    echo "   Logs orderer:"
    docker logs orderer.oliveoil.com --tail 10
    echo "   Logs CLI:"
    docker logs cli --tail 10
    echo ""
    echo "💡 Essayez manuellement:"
    echo '   docker exec cli peer channel create -o orderer.oliveoil.com:7050 -c oliveoilchannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem'
    exit 1
fi

print_step "🎉 RÉSEAU DÉMARRÉ AVEC SUCCÈS! 🎉"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "✅ Réseau Hyperledger Fabric opérationnel"
echo "✅ Orderer en cours d'exécution"
echo "✅ $peer_count/5 peers actifs"
echo "✅ CLI prêt"
echo "✅ Canal 'oliveoilchannel' créé"
echo "✅ Farmer joint au canal"
echo ""
echo "🔗 Points d'accès:"
echo "   • Orderer: orderer.oliveoil.com:7050"
echo "   • Farmer Peer: peer0.farmer.oliveoil.com:7051"
echo "   • Collector Peer: peer0.collector.oliveoil.com:8051"
echo "   • Mill Peer: peer0.mill.oliveoil.com:9051"
echo "   • Distributor Peer: peer0.distributor.oliveoil.com:10051"
echo "   • Retailer Peer: peer0.retailer.oliveoil.com:11051"
echo ""
echo "📋 Prochaines étapes:"
echo "   1. Joindre les autres peers au canal:"
echo "      ./scripts/join-peers-to-channel.sh"
echo ""
echo "   2. Déployer le chaincode:"
echo "      ./scripts/deploy-chaincode.sh"
echo ""
echo "🔧 Commandes utiles:"
echo "   # Vérifier le statut:"
echo "   docker ps"
echo ""
echo "   # Logs d'un conteneur:"
echo "   docker logs orderer.oliveoil.com"
echo "   docker logs peer0.farmer.oliveoil.com"
echo ""
echo "   # Accéder au CLI:"
echo "   docker exec -it cli bash"
echo ""
echo "   # Arrêter le réseau:"
echo "   docker-compose -f docker/docker-compose.yaml down -v"
echo ""
echo "🚀 Réseau prêt pour le déploiement de chaincode!"

echo ""
echo "================================================="
date