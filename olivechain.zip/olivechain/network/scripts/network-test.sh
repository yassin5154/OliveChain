#!/bin/bash
set -e

echo "🧪 TEST COMPLET DU RÉSEAU HYPERLEDGER FABRIC"
echo "============================================"
date

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_step() {
    echo -e "\n${YELLOW}=== $1 ===${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Change to the network directory
cd "$(dirname "$0")/.."

print_step "TEST 1: STATUT DES CONTENEURS"
echo "🐳 Vérification du statut des conteneurs..."

containers=("orderer.oliveoil.com" "peer0.farmer.oliveoil.com" "peer0.collector.oliveoil.com" "peer0.mill.oliveoil.com" "peer0.distributor.oliveoil.com" "peer0.retailer.oliveoil.com" "cli")
running_containers=0

for container in "${containers[@]}"; do
    # Correction: vérifier simplement si le conteneur apparaît dans docker ps (sans -a)
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        print_success "$container est en cours d'exécution"
        ((running_containers++))
    else
        print_error "$container n'est pas en cours d'exécution"
        # Vérifier le statut exact avec docker ps -a
        if docker ps -a --format '{{.Names}}\t{{.Status}}' | grep -q "^${container}"; then
            status=$(docker ps -a --filter name=${container} --format '{{.Status}}')
            echo "   Statut: $status"
        else
            echo "   Conteneur introuvable"
        fi
    fi
done

print_info "Conteneurs actifs: $running_containers/${#containers[@]}"

if [ $running_containers -lt 4 ]; then
    print_error "Pas assez de conteneurs actifs pour continuer les tests"
    
    # Diagnostic supplémentaire
    echo ""
    echo "🔍 DIAGNOSTIC SUPPLÉMENTAIRE:"
    echo "📋 Tous les conteneurs (docker ps):"
    docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
    
    echo ""
    echo "📋 Conteneurs arrêtés (docker ps -a):"
    docker ps -a --filter "status=exited" --format "table {{.Names}}\t{{.Status}}"
    
    echo ""
    echo "💡 Les conteneurs semblent en cours d'exécution. Le problème pourrait être:"
    echo "   1. Démarrage en cours (attendez 1-2 minutes)"
    echo "   2. Erreurs dans les logs"
    echo "   3. Configuration réseau"
    
    echo ""
    echo "🔧 Vérifiez les logs des conteneurs:"
    for container in "${containers[@]}"; do
        if docker ps -a --format '{{.Names}}' | grep -q "^${container}$"; then
            echo "   docker logs $container --tail 10"
        fi
    done
    
    # Ne pas quitter, continuer les tests avec les conteneurs disponibles
    echo ""
    echo "⚠️  Continuation des tests avec les conteneurs disponibles..."
fi

print_step "TEST 2: VÉRIFICATION DÉTAILLÉE DU STATUT"
echo "🔍 Vérification détaillée de chaque conteneur..."

# Test orderer
echo "🏛️ Test de l'orderer:"
if docker ps --format '{{.Names}}' | grep -q "^orderer.oliveoil.com$"; then
    print_success "Orderer conteneur actif"
    
    # Vérifier les logs pour s'assurer qu'il fonctionne
    if docker logs orderer.oliveoil.com 2>&1 | grep -q "Beginning to serve requests"; then
        print_success "Orderer prêt à servir les requêtes"
    elif docker logs orderer.oliveoil.com 2>&1 | grep -q "Starting orderer"; then
        print_info "Orderer en cours de démarrage..."
    else
        print_error "Orderer a des problèmes"
        echo "📋 Derniers logs orderer:"
        docker logs orderer.oliveoil.com --tail 5
    fi
else
    print_error "Orderer non actif"
fi

# Test peers
echo ""
echo "👥 Test des peers:"
active_peers=0
for peer in peer0.farmer.oliveoil.com peer0.collector.oliveoil.com peer0.mill.oliveoil.com peer0.distributor.oliveoil.com peer0.retailer.oliveoil.com; do
    if docker ps --format '{{.Names}}' | grep -q "^${peer}$"; then
        print_success "$peer actif"
        ((active_peers++))
    else
        print_error "$peer non actif"
        if docker ps -a --format '{{.Names}}' | grep -q "^${peer}$"; then
            echo "   Logs récents:"
            docker logs $peer --tail 3
        fi
    fi
done

print_info "Peers actifs: $active_peers/5"

# Test CLI
echo ""
echo "💻 Test du CLI:"
if docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    print_success "CLI actif"
    
    # Test simple pour vérifier que le CLI peut exécuter des commandes
    if timeout 10 docker exec cli echo "CLI test" >/dev/null 2>&1; then
        print_success "CLI répond aux commandes"
    else
        print_error "CLI ne répond pas aux commandes"
    fi
else
    print_error "CLI non actif"
fi

print_step "TEST 3: CONNECTIVITÉ RÉSEAU"
echo "🌐 Test de connectivité entre conteneurs..."

# Test seulement si le CLI est disponible
if docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    # Test de ping vers l'orderer
    if timeout 10 docker exec cli ping -c 2 orderer.oliveoil.com >/dev/null 2>&1; then
        print_success "Connectivité CLI -> Orderer"
    else
        print_error "Échec de connectivité CLI -> Orderer"
    fi

    # Test de ping vers les peers actifs
    for peer in peer0.farmer.oliveoil.com peer0.collector.oliveoil.com peer0.mill.oliveoil.com; do
        if docker ps --format '{{.Names}}' | grep -q "^${peer}$"; then
            if timeout 10 docker exec cli ping -c 2 $peer >/dev/null 2>&1; then
                print_success "Connectivité CLI -> $peer"
            else
                print_error "Échec de connectivité CLI -> $peer"
            fi
        else
            print_info "$peer non disponible pour test de connectivité"
        fi
    done
else
    print_error "CLI non disponible - tests de connectivité ignorés"
fi

print_step "TEST 4: CONNECTIVITÉ TLS"
echo "🔐 Test de connectivité TLS avec l'orderer..."

if docker ps --format '{{.Names}}' | grep -q "^cli$" && docker ps --format '{{.Names}}' | grep -q "^orderer.oliveoil.com$"; then
    if timeout 15 docker exec cli openssl s_client -connect orderer.oliveoil.com:7050 -servername orderer.orderer.oliveoil.com -verify_return_error -CAfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem < /dev/null >/dev/null 2>&1; then
        print_success "Connectivité TLS avec l'orderer OK"
    else
        print_error "Problème de connectivité TLS avec l'orderer"
    fi
else
    print_info "CLI ou Orderer non disponible - test TLS ignoré"
fi

print_step "TEST 5: STATUT DU PEER FARMER"
echo "👨‍🌾 Test du statut du peer farmer..."

if docker ps --format '{{.Names}}' | grep -q "^cli$" && docker ps --format '{{.Names}}' | grep -q "^peer0.farmer.oliveoil.com$"; then
    if timeout 10 docker exec cli peer node status >/dev/null 2>&1; then
        print_success "Peer farmer répond au statut"
    else
        print_error "Peer farmer ne répond pas"
        echo "📋 Logs du peer farmer:"
        docker logs peer0.farmer.oliveoil.com --tail 5
    fi
else
    print_info "CLI ou Peer farmer non disponible - test ignoré"
fi

print_step "TEST 6: CANAUX"
echo "📋 Test des canaux..."

if docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    # Lister les canaux
    echo "🔍 Canaux joints par le peer farmer:"
    if channels=$(docker exec cli peer channel list 2>/dev/null); then
        echo "$channels"
        if echo "$channels" | grep -q "oliveoilchannel"; then
            print_success "Canal 'oliveoilchannel' trouvé"
            
            # Obtenir des informations sur le canal
            echo "📊 Informations du canal oliveoilchannel:"
            if channel_info=$(timeout 15 docker exec cli peer channel getinfo -c oliveoilchannel 2>/dev/null); then
                echo "$channel_info"
                print_success "Informations du canal obtenues"
            else
                print_error "Impossible d'obtenir les informations du canal"
            fi
            
        else
            print_error "Canal 'oliveoilchannel' non trouvé"
        fi
    else
        print_error "Impossible de lister les canaux"
    fi
else
    print_info "CLI non disponible - test des canaux ignoré"
fi

print_step "TEST 7: CHAINCODES"
echo "⛓️ Test des chaincodes..."

if docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    # Lister les chaincodes installés
    echo "📦 Chaincodes installés:"
    if chaincodes=$(timeout 15 docker exec cli peer lifecycle chaincode queryinstalled 2>/dev/null); then
        echo "$chaincodes"
        if echo "$chaincodes" | grep -q "oliveoil"; then
            print_success "Chaincode 'oliveoil' trouvé"
        else
            print_info "Aucun chaincode 'oliveoil' installé"
        fi
    else
        print_info "Aucun chaincode installé ou erreur lors de la requête"
    fi
else
    print_info "CLI non disponible - test des chaincodes ignoré"
fi

print_step "TEST 8: LOGS DES COMPOSANTS"
echo "📋 Vérification des logs pour détecter des erreurs..."

# Vérifier les logs de l'orderer
if docker ps --format '{{.Names}}' | grep -q "^orderer.oliveoil.com$"; then
    echo "🔍 Logs de l'orderer (dernières 10 lignes):"
    docker logs orderer.oliveoil.com --tail 10
    
    # Vérifier si l'orderer est prêt
    if docker logs orderer.oliveoil.com 2>&1 | grep -q "Beginning to serve requests"; then
        print_success "Orderer prêt à servir les requêtes"
    else
        print_error "Orderer pas encore prêt ou en erreur"
    fi
else
    print_info "Orderer non disponible - vérification des logs ignorée"
fi

# Vérifier les logs du peer farmer
if docker ps --format '{{.Names}}' | grep -q "^peer0.farmer.oliveoil.com$"; then
    echo ""
    echo "🔍 Logs du peer farmer (dernières 5 lignes):"
    docker logs peer0.farmer.oliveoil.com --tail 5
else
    print_info "Peer farmer non disponible - vérification des logs ignorée"
fi

print_step "TEST 9: PERFORMANCE ET RESSOURCES"
echo "📈 Statistiques d'utilisation des ressources..."

echo "💾 Utilisation mémoire et CPU:"
if docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}" 2>/dev/null | grep -E "(peer|orderer|cli)"; then
    print_success "Statistiques obtenues"
else
    print_info "Impossible d'obtenir les statistiques"
fi

print_step "RÉSUMÉ DES TESTS"
echo "📊 Résumé de l'état du réseau..."

# Compter les composants fonctionnels
functional_components=0

# Test orderer
if docker ps --format '{{.Names}}' | grep -q "^orderer.oliveoil.com$" && docker logs orderer.oliveoil.com 2>&1 | grep -q "Beginning to serve requests"; then
    ((functional_components++))
    print_success "Orderer: Fonctionnel"
elif docker ps --format '{{.Names}}' | grep -q "^orderer.oliveoil.com$"; then
    print_info "Orderer: En cours de démarrage"
else
    print_error "Orderer: Problématique"
fi

# Test peers
functional_peers=0
for peer in peer0.farmer.oliveoil.com peer0.collector.oliveoil.com peer0.mill.oliveoil.com peer0.distributor.oliveoil.com peer0.retailer.oliveoil.com; do
    if docker ps --format '{{.Names}}' | grep -q "^${peer}$"; then
        ((functional_peers++))
        ((functional_components++))
    fi
done

print_info "Peers fonctionnels: $functional_peers/5"

# Test CLI
if docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    ((functional_components++))
    print_success "CLI: Fonctionnel"
else
    print_error "CLI: Problématique"
fi

# Test canal (seulement si CLI disponible)
if docker ps --format '{{.Names}}' | grep -q "^cli$" && timeout 10 docker exec cli peer channel list 2>/dev/null | grep -q "oliveoilchannel"; then
    ((functional_components++))
    print_success "Canal: Fonctionnel"
elif docker ps --format '{{.Names}}' | grep -q "^cli$"; then
    print_error "Canal: Manquant ou problématique"
else
    print_info "Canal: Non testé (CLI indisponible)"
fi

echo ""
if [ $functional_components -ge 6 ]; then
    echo "🎉 RÉSEAU EN EXCELLENT ÉTAT!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    print_success "Tous les composants critiques sont fonctionnels"
    print_success "Prêt pour le déploiement de chaincode"
elif [ $functional_components -ge 4 ]; then
    echo "⚠️  RÉSEAU PARTIELLEMENT FONCTIONNEL"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    print_info "La plupart des composants fonctionnent"
    print_info "Peut nécessiter quelques ajustements"
else
    echo "❌ RÉSEAU EN DIFFICULTÉ"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    print_error "Plusieurs composants critiques ne fonctionnent pas"
    print_error "Redémarrage recommandé"
fi

echo ""
echo "🔧 COMMANDES UTILES:"
echo "   # Redémarrer le réseau:"
echo "   ./scripts/start-network.sh"
echo ""
echo "   # Logs détaillés:"
echo "   docker logs orderer.oliveoil.com"
echo "   docker logs peer0.farmer.oliveoil.com"
echo ""
echo "   # Accéder au CLI pour tests manuels:"
echo "   docker exec -it cli bash"
echo ""
echo "   # Tests de chaincode (si installé):"
echo "   docker exec cli peer chaincode query -C oliveoilchannel -n oliveoil -c '{\"function\":\"ping\",\"Args\":[]}'"
echo ""
echo "   # Créer le canal (si manquant):"
echo "   docker exec cli peer channel create -o orderer.oliveoil.com:7050 -c oliveoilchannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem"

echo ""
echo "============================================"
date