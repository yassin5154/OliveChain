#!/bin/bash
set -e

echo "📝 Creating channel..."

# Wait for orderer to be ready
sleep 10

# Check if orderer is running
echo "🔍 Checking orderer status..."
if ! docker logs orderer.oliveoil.com 2>&1 | grep -q "Beginning to serve requests"; then
    echo "❌ Orderer is not running properly. Checking logs:"
    docker logs orderer.oliveoil.com --tail 20
    exit 1
fi

echo "📝 Creating channel with peer CLI..."


docker exec cli peer channel create \
    -o orderer.oliveoil.com:7050 \
    -c oliveoilchannel \
    -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx \
    --tls \
    --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
    --ordererTLSHostnameOverride orderer.orderer.oliveoil.com

echo "✅ Channel created successfully"

# Join all peers to channel
echo "📝 Joining peers to channel..."

# Set environment for Farmer organization (déjà configuré dans docker-compose)
docker exec cli peer channel join -b oliveoilchannel.block

echo "✅ Farmer peer joined channel successfully"

# Join other organizations
echo "📝 Joining other peers to channel..."

# Collector
docker exec -e CORE_PEER_LOCALMSPID=CollectorMSP \
    -e CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/collector.oliveoil.com/peers/peer0.collector.oliveoil.com/tls/ca.crt \
    -e CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/collector.oliveoil.com/users/Admin@collector.oliveoil.com/msp \
    -e CORE_PEER_ADDRESS=peer0.collector.oliveoil.com:8051 \
    cli peer channel join -b oliveoilchannel.block

# Mill
docker exec -e CORE_PEER_LOCALMSPID=MillMSP \
    -e CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/mill.oliveoil.com/peers/peer0.mill.oliveoil.com/tls/ca.crt \
    -e CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/mill.oliveoil.com/users/Admin@mill.oliveoil.com/msp \
    -e CORE_PEER_ADDRESS=peer0.mill.oliveoil.com:9051 \
    cli peer channel join -b oliveoilchannel.block

# Distributor
docker exec -e CORE_PEER_LOCALMSPID=DistributorMSP \
    -e CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/distributor.oliveoil.com/peers/peer0.distributor.oliveoil.com/tls/ca.crt \
    -e CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/distributor.oliveoil.com/users/Admin@distributor.oliveoil.com/msp \
    -e CORE_PEER_ADDRESS=peer0.distributor.oliveoil.com:10051 \
    cli peer channel join -b oliveoilchannel.block

# Retailer
docker exec -e CORE_PEER_LOCALMSPID=RetailerMSP \
    -e CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/retailer.oliveoil.com/peers/peer0.retailer.oliveoil.com/tls/ca.crt \
    -e CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/retailer.oliveoil.com/users/Admin@retailer.oliveoil.com/msp \
    -e CORE_PEER_ADDRESS=peer0.retailer.oliveoil.com:11051 \
    cli peer channel join -b oliveoilchannel.block

echo "✅ All peers joined channel successfully"