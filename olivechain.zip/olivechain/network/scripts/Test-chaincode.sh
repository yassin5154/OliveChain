#!/bin/bash
# filepath: c:\Users\HP\Downloads\olivechain\olivechain\network\scripts\simple-test.sh

echo "🔍 TESTING CURRENT CHAINCODE STATUS"
echo "=================================="

# Set environment for Farmer peer
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

CHANNEL_NAME="oliveoilchannel"
CC_NAME="oliveoil"

echo "📋 Step 1: Check installed chaincodes..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer lifecycle chaincode queryinstalled
"

echo ""
echo "📋 Step 2: Check committed chaincodes on channel..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME
"

echo ""
echo "📋 Step 3: Check channels joined..."
docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer channel list
"

echo ""
echo "🧪 Step 4: Try basic chaincode test..."
if docker exec cli bash -c "
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"ping\",\"Args\":[]}'
"; then
    echo "✅ Chaincode is working! Testing batch functions..."
    
    echo ""
    echo "🌾 Testing batch creation..."
    docker exec cli bash -c "
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer chaincode invoke -o orderer.oliveoil.com:7050 \
        --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
        --tls \
        --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
        -C $CHANNEL_NAME \
        -n $CC_NAME \
        --peerAddresses peer0.farmer.oliveoil.com:7051 \
        --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt \
        -c '{\"function\":\"createBatch\",\"Args\":[\"BATCH001\",\"FARMER001\",\"1000\",\"2024-12-01\",\"Spain\"]}'
    "
    
    sleep 3
    
    echo ""
    echo "🌾 Testing batch retrieval..."
    docker exec cli bash -c "
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"getBatch\",\"Args\":[\"BATCH001\"]}'
    "
    
    echo ""
    echo "🌾 Testing get all batches..."
    docker exec cli bash -c "
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"getAllBatches\",\"Args\":[]}'
    "
    
else
    echo "❌ Chaincode not found or not working"
    echo ""
    echo "💡 You need to deploy the chaincode first. Try:"
    echo "   ./scripts/deploy-simple-batch.sh"
    echo "   or"
    echo "   ./scripts/fix-channel-and-deploy.sh"
fi

echo ""
echo "======================================"
date