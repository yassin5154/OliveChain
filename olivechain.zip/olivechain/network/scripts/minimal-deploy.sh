#!/bin/bash
# filepath: c:\Users\HP\Downloads\olivechain\olivechain\network\scripts\emergency-deploy.sh

echo "🚨 EMERGENCY CHAINCODE DEPLOYMENT - PRESENTATION MODE"
echo "====================================================="

CHANNEL_NAME="oliveoilchannel"
CC_NAME="oliveoil"
CC_VERSION="1.0"
SEQUENCE="1"

# Kill any hanging processes
echo "🧹 Cleaning up hanging processes..."
docker exec cli pkill -f peer 2>/dev/null || true
docker exec cli pkill -f chaincode 2>/dev/null || true
sleep 5

echo "🔄 Restarting peer to clear any locks..."
docker restart peer0.farmer.oliveoil.com
docker restart peer0.collector.oliveoil.com
docker restart peer0.mill.oliveoil.com
sleep 20

# Use the existing package ID
PACKAGE_ID="oliveoil_fresh_1.0:c87711e3c89b45dc73ab6985a60272ea605aac6794dc0589603f086d4ec8b0a2"

echo "📋 Using Package ID: $PACKAGE_ID"

echo ""
echo "🔥 EMERGENCY Step 1: Force approve with extended timeout..."

# Try approval with extended settings
for attempt in {1..3}; do
    echo "Approval attempt $attempt/3..."
    
    if timeout 600 docker exec cli bash -c "
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer lifecycle chaincode approveformyorg \
        -o orderer.oliveoil.com:7050 \
        --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
        --tls \
        --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
        --channelID $CHANNEL_NAME \
        --name $CC_NAME \
        --version $CC_VERSION \
        --package-id $PACKAGE_ID \
        --sequence $SEQUENCE
    "; then
        echo "✅ FarmerMSP approved successfully!"
        break
    else
        echo "❌ Attempt $attempt failed"
        if [ $attempt -lt 3 ]; then
            echo "⏳ Waiting 30s before retry..."
            docker exec cli pkill -f peer 2>/dev/null || true
            sleep 30
        fi
    fi
done

sleep 15

echo ""
echo "🔥 EMERGENCY Step 2: Force commit with multiple attempts..."

for attempt in {1..3}; do
    echo "Commit attempt $attempt/3..."
    
    if timeout 600 docker exec cli bash -c "
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer lifecycle chaincode commit \
        -o orderer.oliveoil.com:7050 \
        --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
        --tls \
        --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
        --channelID $CHANNEL_NAME \
        --name $CC_NAME \
        --version $CC_VERSION \
        --sequence $SEQUENCE \
        --peerAddresses peer0.farmer.oliveoil.com:7051 \
        --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    "; then
        echo "✅ Chaincode committed successfully!"
        break
    else
        echo "❌ Commit attempt $attempt failed"
        if [ $attempt -lt 3 ]; then
            echo "⏳ Waiting 45s before retry..."
            sleep 45
        fi
    fi
done

sleep 30

echo ""
echo "🔥 EMERGENCY Step 3: Initialize chaincode..."

for attempt in {1..3}; do
    echo "Initialization attempt $attempt/3..."
    
    if timeout 300 docker exec cli bash -c "
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer chaincode invoke \
        -o orderer.oliveoil.com:7050 \
        --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
        --tls \
        --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
        -C $CHANNEL_NAME \
        -n $CC_NAME \
        --peerAddresses peer0.farmer.oliveoil.com:7051 \
        --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt \
        -c '{\"function\":\"initLedger\",\"Args\":[]}'
    "; then
        echo "✅ Chaincode initialized successfully!"
        break
    else
        echo "❌ Initialization attempt $attempt failed"
        if [ $attempt -lt 3 ]; then
            echo "⏳ Waiting 30s before retry..."
            sleep 30
        fi
    fi
done

sleep 15

echo ""
echo "🧪 EMERGENCY TESTS..."

# Test ping
echo "Testing ping..."
if timeout 60 docker exec cli bash -c "
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"ping\",\"Args\":[]}'
"; then
    echo "✅ PING WORKS!"
    
    # Test batch creation
    echo ""
    echo "Testing batch creation..."
    if timeout 120 docker exec cli bash -c "
    export CORE_PEER_TLS_ENABLED=true
    export CORE_PEER_LOCALMSPID=FarmerMSP
    export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
    export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
    export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

    peer chaincode invoke \
        -o orderer.oliveoil.com:7050 \
        --ordererTLSHostnameOverride orderer.orderer.oliveoil.com \
        --tls \
        --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem \
        -C $CHANNEL_NAME \
        -n $CC_NAME \
        --peerAddresses peer0.farmer.oliveoil.com:7051 \
        --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt \
        -c '{\"function\":\"createBatch\",\"Args\":[\"DEMO_BATCH_001\",\"FARMER001\",\"1000\",\"2024-12-02\",\"Spain\"]}'
    "; then
        echo "✅ BATCH CREATION WORKS!"
        
        sleep 5
        
        # Test batch retrieval
        echo ""
        echo "Testing batch retrieval..."
        if timeout 60 docker exec cli bash -c "
        export CORE_PEER_TLS_ENABLED=true
        export CORE_PEER_LOCALMSPID=FarmerMSP
        export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
        export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
        export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

        peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"getBatch\",\"Args\":[\"DEMO_BATCH_001\"]}'
        "; then
            echo "✅ BATCH RETRIEVAL WORKS!"
            
            echo ""
            echo "Testing get all batches..."
            timeout 60 docker exec cli bash -c "
            export CORE_PEER_TLS_ENABLED=true
            export CORE_PEER_LOCALMSPID=FarmerMSP
            export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
            export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
            export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

            peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{\"function\":\"getAllBatches\",\"Args\":[]}'
            " && echo "✅ GET ALL BATCHES WORKS!"
            
        else
            echo "❌ Batch retrieval failed"
        fi
    else
        echo "❌ Batch creation failed"
    fi
else
    echo "❌ Ping failed"
fi

echo ""
echo "📋 Final status check..."
timeout 30 docker exec cli bash -c "
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID=FarmerMSP
export CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/peers/peer0.farmer.oliveoil.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/farmer.oliveoil.com/users/Admin@farmer.oliveoil.com/msp
export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051

peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME
" || echo "⚠️ Query commit status timeout"

echo ""
echo "🎯 PRESENTATION COMMANDS (copy these for demo):"
echo "=============================================="
echo ""
echo "# 1. Test ping:"
echo 'docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode query -C oliveoilchannel -n oliveoil -c '"'"'{"function":"ping","Args":[]}'"'"'"'
echo ""
echo "# 2. Create a batch:"
echo 'docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode invoke -C oliveoilchannel -n oliveoil -c '"'"'{"function":"createBatch","Args":["PRESENTATION_BATCH","FARMER_DEMO","2000","2024-12-02","Premium_Spain"]}'"'"' -o orderer.oliveoil.com:7050 --ordererTLSHostnameOverride orderer.orderer.oliveoil.com --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/orderer.oliveoil.com/orderers/orderer.orderer.oliveoil.com/msp/tlscacerts/tlsca.orderer.oliveoil.com-cert.pem"'
echo ""
echo "# 3. Get the batch:"
echo 'docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode query -C oliveoilchannel -n oliveoil -c '"'"'{"function":"getBatch","Args":["PRESENTATION_BATCH"]}'"'"'"'
echo ""
echo "# 4. Get all batches:"
echo 'docker exec cli bash -c "export CORE_PEER_LOCALMSPID=FarmerMSP && export CORE_PEER_ADDRESS=peer0.farmer.oliveoil.com:7051 && peer chaincode query -C oliveoilchannel -n oliveoil -c '"'"'{"function":"getAllBatches","Args":[]}'"'"'"'

echo ""
echo "🚨 EMERGENCY DEPLOYMENT STATUS:"
if timeout 30 docker exec cli peer chaincode query -C oliveoilchannel -n oliveoil -c '{"function":"ping","Args":[]}' 2>/dev/null | grep -q "pong"; then
    echo "✅ SUCCESS! Your chaincode is working and ready for presentation!"
else
    echo "❌ Still having issues. Try nuclear option below..."
fi

echo ""
echo "======================================"
date