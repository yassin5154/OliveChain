# OliveChain - Hyperledger Fabric Implementation

This project implements a blockchain solution using Hyperledger Fabric with CouchDB as the state database.

## Prerequisites

- Docker and Docker Compose
- Node.js v12 or higher
- npm v6.9.0 or higher
- Hyperledger Fabric binaries and Docker images

## Setup Instructions

1. Install Hyperledger Fabric binaries and Docker images:

```bash
curl -sSL https://bit.ly/2ysbOFE | bash -s -- 2.2.19 1.5.5
```

2. Set up the Fabric network:

```bash
cd network
./network.sh up createChannel -c olivechannel -ca -s couchdb
```

3. Deploy the chaincode:

```bash
./network.sh deployCC -ccn olivechain -ccp ../chaincode/olivechain -ccl javascript
```

4. Install dependencies:

```bash
npm install
```

5. Set up environment variables:

```bash
cp .env.example .env
```

Edit the .env file with your configuration:

```
PORT=3000
FABRIC_CHANNEL_NAME=olivechannel
FABRIC_CHAINCODE_NAME=olivechain
```

6. Start the application:

```bash
npm run dev
```

## Project Structure

- `/chaincode` - Hyperledger Fabric chaincode implementation
- `/network` - Fabric network configuration files
- `/backend` - Express.js API server
- `/src` - Frontend React application

## API Endpoints

- POST `/api/blocks` - Add a new block
- GET `/api/blocks/:hash` - Get block by hash
- GET `/api/blocks` - Get all blocks
- GET `/api/validate` - Validate the blockchain

## CouchDB

The CouchDB state database is accessible at:

- URL: http://localhost:5984/\_utils
- Username: admin
- Password: adminpw

## Development

1. Start the development server:

```bash
npm run dev
```

2. Access the application:

- Frontend: http://localhost:5173
- Backend API: http://localhost:3000
- CouchDB UI: http://localhost:5984/\_utils

## Troubleshooting

1. If you encounter network issues:

```bash
./network.sh down
./network.sh up createChannel -c olivechannel -ca -s couchdb
./network.sh deployCC -ccn olivechain -ccp ../chaincode/olivechain -ccl javascript
```

2. To reset the environment:

```bash
docker-compose down
docker volume prune
./network.sh down
```

## License

MIT
