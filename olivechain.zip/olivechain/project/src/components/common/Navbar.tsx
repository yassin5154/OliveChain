import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Leaf, LogOut, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ORGANIZATIONS } from '../../utils/constants';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const orgInfo = user ? ORGANIZATIONS.find(org => org.id === user.organization) : null;

  return (
    <nav className="bg-gradient-to-r from-olive-800 to-olive-900 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center" onClick={() => navigate('/')}>
              <Leaf className="h-8 w-8 text-olive-300" />
              <span className="ml-2 text-xl font-semibold tracking-wider cursor-pointer">OliveChain</span>
            </div>
            {user && (
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <button 
                    onClick={() => navigate('/dashboard')}
                    className="px-3 py-2 rounded-md text-sm font-medium hover:bg-olive-700 hover:text-white transition-colors"
                  >
                    Dashboard
                  </button>
                  <button 
                    onClick={() => navigate('/batches')}
                    className="px-3 py-2 rounded-md text-sm font-medium hover:bg-olive-700 hover:text-white transition-colors"
                  >
                    Batch Management
                  </button>
                  <button 
                    onClick={() => navigate('/trace')}
                    className="px-3 py-2 rounded-md text-sm font-medium hover:bg-olive-700 hover:text-white transition-colors"
                  >
                    Traceability
                  </button>
                </div>
              </div>
            )}
          </div>
          {user ? (
            <div className="flex items-center">
              <div className="flex items-center mr-4">
                <div className={`w-3 h-3 rounded-full ${orgInfo?.color || 'bg-gray-400'} mr-2`}></div>
                <span className="text-sm hidden sm:inline-block">{user.role.charAt(0).toUpperCase() + user.role.slice(1)}</span>
              </div>
              <div className="ml-3 relative flex items-center">
                <div className="text-sm font-medium leading-none text-white mr-4 hidden md:block">
                  {user.name}
                </div>
                <button 
                  className="p-1 rounded-full text-olive-200 hover:text-white focus:outline-none" 
                  onClick={() => navigate('/profile')}
                >
                  <User className="h-6 w-6" />
                </button>
                <button 
                  className="ml-2 p-1 rounded-full text-olive-200 hover:text-white focus:outline-none" 
                  onClick={handleLogout}
                >
                  <LogOut className="h-6 w-6" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center">
              <button 
                onClick={() => navigate('/login')}
                className="bg-olive-700 hover:bg-olive-600 px-4 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Login
              </button>
            </div>
          )}
        </div>
      </div>
      {user && (
        <div className="md:hidden">
          <div className="flex flex-col px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button 
              onClick={() => navigate('/dashboard')}
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700 hover:text-white"
            >
              Dashboard
            </button>
            <button 
              onClick={() => navigate('/batches')}
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700 hover:text-white"
            >
              Batch Management
            </button>
            <button 
              onClick={() => navigate('/trace')}
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-olive-700 hover:text-white"
            >
              Traceability
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;