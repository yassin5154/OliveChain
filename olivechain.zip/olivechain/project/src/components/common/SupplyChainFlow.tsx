import React from 'react';
import { Leaf, Factory, FlaskRound as Flask, ClipboardCheck, Truck, Store } from 'lucide-react';
import { OliveBatch } from '../../context/BlockchainContext';
import { SUPPLY_CHAIN_STAGES } from '../../utils/constants';

interface SupplyChainFlowProps {
  batch: OliveBatch;
}

const SupplyChainFlow: React.FC<SupplyChainFlowProps> = ({ batch }) => {
  // Get the current stage index
  const currentStageIndex = SUPPLY_CHAIN_STAGES.findIndex(stage => stage.id === batch.state);

  // Function to get icon based on stage
  const getIcon = (stageId: string) => {
    switch (stageId) {
      case 'HARVESTED':
        return <Leaf className="h-6 w-6" />;
      case 'PRESSED':
        return <Factory className="h-6 w-6" />;
      case 'BOTTLED':
        return <Flask className="h-6 w-6" />;
      case 'QUALITY_CHECKED':
        return <ClipboardCheck className="h-6 w-6" />;
      case 'DISTRIBUTED':
        return <Truck className="h-6 w-6" />;
      case 'RETAIL':
        return <Store className="h-6 w-6" />;
      default:
        return null;
    }
  };

  // Find the timestamp for a specific stage from the batch history
  const getStageTimestamp = (stageId: string) => {
    const historyItem = batch.history.find(item => item.state === stageId);
    return historyItem ? new Date(historyItem.timestamp).toLocaleString() : null;
  };

  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-between w-full mb-8">
        <div className="w-full flex">
          {SUPPLY_CHAIN_STAGES.map((stage, index) => {
            // Determine if this stage is completed, current, or upcoming
            const isCompleted = index <= currentStageIndex;
            const isCurrent = index === currentStageIndex;
            const hasTimestamp = getStageTimestamp(stage.id);
            
            return (
              <div key={stage.id} className="flex-1 relative flex flex-col items-center">
                {/* Connector line */}
                {index > 0 && (
                  <div 
                    className={`absolute top-5 w-full h-1 -left-1/2 ${
                      index <= currentStageIndex ? stage.color : 'bg-gray-200'
                    }`}
                  ></div>
                )}
                
                {/* Stage circle */}
                <div 
                  className={`
                    z-10 flex items-center justify-center w-10 h-10 rounded-full 
                    ${isCompleted ? stage.color : 'bg-gray-200'}
                    ${isCurrent ? 'ring-4 ring-offset-2 ring-' + stage.color.replace('bg-', '') + '/30' : ''}
                    text-white transition-all duration-500
                  `}
                >
                  {getIcon(stage.id)}
                </div>
                
                {/* Stage label */}
                <div className="mt-2 text-center">
                  <div className={`text-sm font-medium ${isCompleted ? 'text-gray-900' : 'text-gray-500'}`}>
                    {stage.label}
                  </div>
                  {hasTimestamp && (
                    <div className="text-xs text-gray-500 mt-1">
                      {getStageTimestamp(stage.id)}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SupplyChainFlow;