import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Leaf, Factory, ClipboardCheck, FlaskRound as Flask, Truck, Store } from 'lucide-react';
import { OliveBatch, BatchStatus } from '../../context/BlockchainContext';
import { SUPPLY_CHAIN_STAGES } from '../../utils/constants';

interface BatchCardProps {
  batch: OliveBatch;
}

const BatchCard: React.FC<BatchCardProps> = ({ batch }) => {
  const navigate = useNavigate();

  // Get the current stage index
  const currentStageIndex = SUPPLY_CHAIN_STAGES.findIndex(stage => stage.id === batch.state);

  // Function to render the appropriate icon based on batch state
  const renderIcon = (status: BatchStatus) => {
    switch (status) {
      case 'HARVESTED':
        return <Leaf className="h-5 w-5" />;
      case 'PRESSED':
        return <Factory className="h-5 w-5" />;
      case 'BOTTLED':
        return <Flask className="h-5 w-5" />;
      case 'QUALITY_CHECKED':
        return <ClipboardCheck className="h-5 w-5" />;
      case 'DISTRIBUTED':
        return <Truck className="h-5 w-5" />;
      case 'RETAIL':
        return <Store className="h-5 w-5" />;
      default:
        return <Leaf className="h-5 w-5" />;
    }
  };

  // Get the stage color for the current status
  const getCurrentStageColor = () => {
    const stage = SUPPLY_CHAIN_STAGES.find(stage => stage.id === batch.state);
    return stage?.color || 'bg-gray-400';
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden cursor-pointer"
      onClick={() => navigate(`/batches/${batch.batchId}`)}
    >
      <div className={`${getCurrentStageColor()} h-2`}></div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">{batch.batchId}</h3>
            <p className="text-sm text-gray-500">{batch.origin}</p>
          </div>
          <div className={`${getCurrentStageColor()} text-white p-2 rounded-md flex items-center`}>
            {renderIcon(batch.state)}
          </div>
        </div>
        
        <div className="mb-4">
          <p className="text-sm text-gray-600">
            <span className="font-medium">Harvested:</span> {formatDate(batch.harvestDate)}
          </p>
          {batch.millDate && (
            <p className="text-sm text-gray-600">
              <span className="font-medium">Milled:</span> {formatDate(batch.millDate)}
            </p>
          )}
        </div>
        
        <div className="pt-3 border-t border-gray-100">
          <div className="flex justify-between mb-2">
            <span className="text-xs text-gray-500">Supply Chain Progress</span>
            <span className="text-xs font-medium text-gray-700">
              {Math.round(((currentStageIndex + 1) / SUPPLY_CHAIN_STAGES.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div 
              className={`h-1.5 rounded-full ${getCurrentStageColor()}`} 
              style={{ width: `${((currentStageIndex + 1) / SUPPLY_CHAIN_STAGES.length) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchCard;