import React, { useEffect, useState } from 'react';

interface QRCodeGeneratorProps {
  data: string;
  size?: number;
}

const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ data, size = 200 }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');

  useEffect(() => {
    // Generate QR code using an external API
    const encodedData = encodeURIComponent(data);
    setQrCodeUrl(`https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodedData}&color=556B2F`);
  }, [data, size]);

  return (
    <div className="flex flex-col items-center">
      <div className="bg-white p-4 rounded-lg shadow">
        {qrCodeUrl ? (
          <img src={qrCodeUrl} alt={`QR Code for ${data}`} width={size} height={size} />
        ) : (
          <div className="flex items-center justify-center" style={{ width: size, height: size }}>
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-olive-700"></div>
          </div>
        )}
      </div>
      <p className="mt-3 text-sm text-gray-600 text-center">Scan to verify batch authenticity</p>
    </div>
  );
};

export default QRCodeGenerator;