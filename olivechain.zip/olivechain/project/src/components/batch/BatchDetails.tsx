import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, XCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useBlockchain, BatchStatus } from '../../context/BlockchainContext';
import SupplyChainFlow from '../common/SupplyChainFlow';
import QRCodeGenerator from '../common/QRCodeGenerator';
import { SUPPLY_CHAIN_STAGES } from '../../utils/constants';

const BatchDetails: React.FC = () => {
  const { batchId } = useParams<{ batchId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getBatch, updateBatchStatus, loading } = useBlockchain();
  
  const batch = getBatch(batchId || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const [qualityData, setQualityData] = useState({
    acidity: 0,
    peroxides: 0,
    polyphenols: 0,
    rating: 0,
  });
  
  // Add state for other stage data
  const [pressingData, setPressingData] = useState({
    millLocation: '',
    extractionMethod: '',
    temperature: 0,
    pressure: 0,
    yield: 0,
    notes: '',
  });

  const [bottlingData, setBottlingData] = useState({
    bottleLocation: '',
    bottleType: '',
    volume: 0,
    batchNumber: '',
    notes: '',
  });

  const [distributionData, setDistributionData] = useState({
    storageConditions: '',
    transportMethod: '',
    destination: '',
    notes: '',
  });

  const [retailData, setRetailData] = useState({
    location: '',
    price: 0,
    notes: '',
  });
  
  if (!batch) {
    return (
      <div className="min-h-screen bg-gray-50 pt-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <XCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Batch Not Found</h2>
            <p className="text-gray-600 mb-6">The olive oil batch you're looking for doesn't exist or has been removed.</p>
            <button
              onClick={() => navigate('/batches')}
              className="inline-flex items-center px-4 py-2 bg-olive-600 text-white rounded-md hover:bg-olive-700"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Return to Batch List
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Find the current stage and the next stage
  const currentStageIndex = SUPPLY_CHAIN_STAGES.findIndex(stage => stage.id === batch.state);
  const nextStage = SUPPLY_CHAIN_STAGES[currentStageIndex + 1];
  
  // Check if the current user can update this batch
  const canUpdate = nextStage && user?.role === nextStage.role;

  const handleUpdateStatus = async () => {
    if (!nextStage) return;
    
    setIsUpdating(true);
    
    try {
      let additionalData = {};
      
      // Add stage-specific data
      switch (nextStage.id) {
        case 'PRESSED':
          additionalData = {
            millDate: new Date().toISOString().split('T')[0],
            millLocation: pressingData.millLocation,
            extractionMethod: pressingData.extractionMethod,
            temperature: pressingData.temperature,
            pressure: pressingData.pressure,
            yield: pressingData.yield,
            notes: pressingData.notes
          };
          break;
        case 'BOTTLED':
          additionalData = {
            bottleDate: new Date().toISOString().split('T')[0],
            bottleLocation: bottlingData.bottleLocation,
            bottleType: bottlingData.bottleType,
            volume: bottlingData.volume,
            batchNumber: bottlingData.batchNumber,
            notes: bottlingData.notes
          };
          break;
        case 'QUALITY_CHECKED':
          additionalData = { 
            quality: {
              acidity: qualityData.acidity,
              peroxides: qualityData.peroxides,
              polyphenols: qualityData.polyphenols,
              rating: qualityData.rating
            }
          };
          break;
        case 'DISTRIBUTED':
          additionalData = {
            distributor: user?.name,
            distributionDate: new Date().toISOString().split('T')[0],
            storageConditions: distributionData.storageConditions,
            transportMethod: distributionData.transportMethod,
            destination: distributionData.destination,
            notes: distributionData.notes
          };
          break;
        case 'RETAIL':
          additionalData = {
            retailer: user?.name,
            retailDate: new Date().toISOString().split('T')[0],
            location: retailData.location,
            price: retailData.price,
            notes: retailData.notes
          };
          break;
      }
      
      await updateBatchStatus(batch.batchId, nextStage.id as BatchStatus, additionalData);
      setIsUpdating(false);
    } catch (error) {
      console.error('Failed to update batch status:', error);
      setIsUpdating(false);
    }
  };
  
  // Handle quality data change when QC org is inputting data
  const handleQualityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setQualityData(prev => ({
      ...prev,
      [name]: parseFloat(value)
    }));
  };

  // Add handlers for other stage data
  const handlePressingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPressingData(prev => ({
      ...prev,
      [name]: ['millLocation', 'extractionMethod', 'notes'].includes(name) 
        ? value 
        : parseFloat(value) || 0
    }));
  };

  const handleBottlingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setBottlingData(prev => ({
      ...prev,
      [name]: ['bottleLocation', 'bottleType', 'batchNumber', 'notes'].includes(name)
        ? value
        : parseFloat(value) || 0
    }));
  };

  const handleDistributionChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDistributionData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleRetailChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setRetailData(prev => ({
      ...prev,
      [name]: ['location', 'notes'].includes(name) ? value : parseFloat(value) || 0
    }));
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-10 px-4 pb-16">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <button
            onClick={() => navigate('/batches')}
            className="inline-flex items-center text-olive-700 hover:text-olive-800"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Batch List
          </button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">{batch.batchId}</h1>
                  <p className="text-gray-600">{batch.origin}</p>
                </div>
                <div className="flex items-center">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    SUPPLY_CHAIN_STAGES.find(stage => stage.id === batch.state)?.color.replace('bg-', 'bg-opacity-20 text-')
                  }`}>
                    {SUPPLY_CHAIN_STAGES.find(stage => stage.id === batch.state)?.label}
                  </span>
                </div>
              </div>
              
              <div className="mb-6">
                <SupplyChainFlow batch={batch} />
              </div>

              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-3">Batch Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Harvest Date</p>
                    <p className="text-md font-medium">{formatDate(batch.harvestDate)}</p>
                  </div>
                  
                  {batch.millDate && (
                    <div>
                      <p className="text-sm text-gray-500">Mill Date</p>
                      <p className="text-md font-medium">{formatDate(batch.millDate)}</p>
                    </div>
                  )}
                  
                  {batch.bottleDate && (
                    <div>
                      <p className="text-sm text-gray-500">Bottle Date</p>
                      <p className="text-md font-medium">{formatDate(batch.bottleDate)}</p>
                    </div>
                  )}
                  
                  {batch.distributor && (
                    <div>
                      <p className="text-sm text-gray-500">Distributor</p>
                      <p className="text-md font-medium">{batch.distributor}</p>
                    </div>
                  )}
                  
                  {batch.retailer && (
                    <div>
                      <p className="text-sm text-gray-500">Retailer</p>
                      <p className="text-md font-medium">{batch.retailer}</p>
                    </div>
                  )}
                </div>
              </div>
              
              {batch.quality && (
                <div className="mb-6">
                  <h2 className="text-lg font-semibold text-gray-800 mb-3">Quality Assessment</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Acidity</p>
                      <p className="text-md font-medium">{batch.quality.acidity}%</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Peroxides</p>
                      <p className="text-md font-medium">{batch.quality.peroxides} meq O2/kg</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Polyphenols</p>
                      <p className="text-md font-medium">{batch.quality.polyphenols} mg/kg</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-500">Quality Rating</p>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <svg 
                            key={i}
                            className={`h-5 w-5 ${i < (batch.quality?.rating || 0) ? 'text-yellow-400' : 'text-gray-300'}`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div>
                <h2 className="text-lg font-semibold text-gray-800 mb-3">Transaction History</h2>
                <div className="space-y-3">
                  {batch.history.map((event, index) => (
                    <div key={index} className="flex items-center border-b border-gray-100 pb-3">
                      <div className={`w-3 h-3 rounded-full ${
                        SUPPLY_CHAIN_STAGES.find(stage => stage.id === event.state)?.color
                      } mr-3`}></div>
                      <div>
                        <p className="text-sm font-medium text-gray-800">
                          {SUPPLY_CHAIN_STAGES.find(stage => stage.id === event.state)?.label}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(event.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {canUpdate && nextStage && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <Edit className="h-5 w-5 text-olive-600 mr-2" />
                  <h2 className="text-lg font-semibold text-gray-800">Update Batch Status</h2>
                </div>
                
                <p className="text-gray-600 mb-4">
                  You can update this batch to the next stage: <span className="font-medium">{nextStage.label}</span>
                </p>
                
                {nextStage.id === 'PRESSED' && (
                  <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="millLocation" className="block text-sm font-medium text-gray-700 mb-1">
                        Mill Location
                      </label>
                      <input
                        type="text"
                        id="millLocation"
                        name="millLocation"
                        value={pressingData.millLocation}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="extractionMethod" className="block text-sm font-medium text-gray-700 mb-1">
                        Extraction Method
                      </label>
                      <input
                        type="text"
                        id="extractionMethod"
                        name="extractionMethod"
                        value={pressingData.extractionMethod}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="temperature" className="block text-sm font-medium text-gray-700 mb-1">
                        Temperature (°C)
                      </label>
                      <input
                        type="number"
                        id="temperature"
                        name="temperature"
                        value={pressingData.temperature}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="pressure" className="block text-sm font-medium text-gray-700 mb-1">
                        Pressure (bar)
                      </label>
                      <input
                        type="number"
                        id="pressure"
                        name="pressure"
                        value={pressingData.pressure}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="yield" className="block text-sm font-medium text-gray-700 mb-1">
                        Yield (%)
                      </label>
                      <input
                        type="number"
                        id="yield"
                        name="yield"
                        value={pressingData.yield}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                        Notes
                      </label>
                      <textarea
                        id="notes"
                        name="notes"
                        value={pressingData.notes}
                        onChange={handlePressingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        rows={3}
                      />
                    </div>
                  </div>
                )}

                {nextStage.id === 'BOTTLED' && (
                  <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="bottleLocation" className="block text-sm font-medium text-gray-700 mb-1">
                        Bottle Location
                      </label>
                      <input
                        type="text"
                        id="bottleLocation"
                        name="bottleLocation"
                        value={bottlingData.bottleLocation}
                        onChange={handleBottlingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="bottleType" className="block text-sm font-medium text-gray-700 mb-1">
                        Bottle Type
                      </label>
                      <input
                        type="text"
                        id="bottleType"
                        name="bottleType"
                        value={bottlingData.bottleType}
                        onChange={handleBottlingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="volume" className="block text-sm font-medium text-gray-700 mb-1">
                        Volume (ml)
                      </label>
                      <input
                        type="number"
                        id="volume"
                        name="volume"
                        value={bottlingData.volume}
                        onChange={handleBottlingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="batchNumber" className="block text-sm font-medium text-gray-700 mb-1">
                        Batch Number
                      </label>
                      <input
                        type="text"
                        id="batchNumber"
                        name="batchNumber"
                        value={bottlingData.batchNumber}
                        onChange={handleBottlingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                        Notes
                      </label>
                      <textarea
                        id="notes"
                        name="notes"
                        value={bottlingData.notes}
                        onChange={handleBottlingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        rows={3}
                      />
                    </div>
                  </div>
                )}

                {nextStage.id === 'QUALITY_CHECKED' && (
                  <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="acidity" className="block text-sm font-medium text-gray-700 mb-1">
                        Acidity (%)
                      </label>
                      <input
                        type="number"
                        id="acidity"
                        name="acidity"
                        min="0"
                        max="5"
                        step="0.1"
                        value={qualityData.acidity}
                        onChange={handleQualityChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="peroxides" className="block text-sm font-medium text-gray-700 mb-1">
                        Peroxides (meq O2/kg)
                      </label>
                      <input
                        type="number"
                        id="peroxides"
                        name="peroxides"
                        min="0"
                        step="0.1"
                        value={qualityData.peroxides}
                        onChange={handleQualityChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="polyphenols" className="block text-sm font-medium text-gray-700 mb-1">
                        Polyphenols (mg/kg)
                      </label>
                      <input
                        type="number"
                        id="polyphenols"
                        name="polyphenols"
                        min="0"
                        step="0.1"
                        value={qualityData.polyphenols}
                        onChange={handleQualityChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="rating" className="block text-sm font-medium text-gray-700 mb-1">
                        Quality Rating (0-5)
                      </label>
                      <input
                        type="number"
                        id="rating"
                        name="rating"
                        min="0"
                        max="5"
                        step="0.1"
                        value={qualityData.rating}
                        onChange={handleQualityChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                  </div>
                )}

                {nextStage.id === 'DISTRIBUTED' && (
                  <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="storageConditions" className="block text-sm font-medium text-gray-700 mb-1">
                        Storage Conditions
                      </label>
                      <input
                        type="text"
                        id="storageConditions"
                        name="storageConditions"
                        value={distributionData.storageConditions}
                        onChange={handleDistributionChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="transportMethod" className="block text-sm font-medium text-gray-700 mb-1">
                        Transport Method
                      </label>
                      <input
                        type="text"
                        id="transportMethod"
                        name="transportMethod"
                        value={distributionData.transportMethod}
                        onChange={handleDistributionChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-1">
                        Destination
                      </label>
                      <input
                        type="text"
                        id="destination"
                        name="destination"
                        value={distributionData.destination}
                        onChange={handleDistributionChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                        Notes
                      </label>
                      <textarea
                        id="notes"
                        name="notes"
                        value={distributionData.notes}
                        onChange={handleDistributionChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        rows={3}
                      />
                    </div>
                  </div>
                )}

                {nextStage.id === 'RETAIL' && (
                  <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                        Location
                      </label>
                      <input
                        type="text"
                        id="location"
                        name="location"
                        value={retailData.location}
                        onChange={handleRetailChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
                        Price (DH)
                      </label>
                      <input
                        type="number"
                        id="price"
                        name="price"
                        min="0"
                        step="0.01"
                        value={retailData.price}
                        onChange={handleRetailChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                        Notes
                      </label>
                      <textarea
                        id="notes"
                        name="notes"
                        value={retailData.notes}
                        onChange={handleRetailChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                        rows={3}
                      />
                    </div>
                  </div>
                )}
                
                <button
                  onClick={handleUpdateStatus}
                  disabled={isUpdating || loading}
                  className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-olive-600 hover:bg-olive-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500 disabled:opacity-50"
                >
                  {isUpdating ? 'Updating...' : `Update to ${nextStage.label}`}
                </button>
              </div>
            )}
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Verification</h2>
              <div className="flex justify-center mb-4">
                <QRCodeGenerator data={`https://olivechain.example.com/verify/${batch.batchId}`} />
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Batch Verification Link</p>
                <a
                  href={`#/verify/${batch.batchId}`}
                  className="text-olive-600 hover:text-olive-800 text-sm break-all"
                >
                  olivechain.example.com/verify/{batch.batchId}
                </a>
              </div>
            </div>

            {/* Add Verification Section */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-3">Verification</h2>
              <div className="flex flex-col items-center bg-gray-50 p-6 rounded-lg border border-gray-200">
                <p className="text-sm text-gray-600 mb-4">Share this link to allow customers to verify this batch:</p>
                <div className="text-center w-full">
                  <div className="bg-white p-3 rounded border border-gray-300 break-all mb-4">
                    {`${window.location.origin}/#/verify/${batch.batchId}`}
                  </div>
                  <a 
                    href={`/#/verify/${batch.batchId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block px-4 py-2 bg-olive-600 text-white rounded-md hover:bg-olive-700 transition-colors"
                  >
                    Test Verification Link
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchDetails;