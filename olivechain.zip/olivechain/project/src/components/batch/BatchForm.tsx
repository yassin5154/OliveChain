import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useBlockchain } from '../../context/BlockchainContext';

interface BatchFormProps {
  onSuccess?: () => void;
}

const BatchForm: React.FC<BatchFormProps> = ({ onSuccess }) => {
  const { user } = useAuth();
  const { addBatch, loading } = useBlockchain();

  const [formData, setFormData] = useState({
    batchId: '',
    origin: '',
    harvestDate: new Date().toISOString().split('T')[0],
    oliveType: '',
    harvestMethod: 'manual',
    notes: '',
  });

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    // Basic validation
    if (!formData.batchId || !formData.origin || !formData.harvestDate) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      await addBatch({
        batchId: formData.batchId,
        origin: formData.origin,
        harvestDate: formData.harvestDate,
        oliveType: formData.oliveType,
        harvestMethod: formData.harvestMethod,
        notes: formData.notes,
      });
      
      setSuccess(true);
      setFormData({
        batchId: '',
        origin: '',
        harvestDate: new Date().toISOString().split('T')[0],
        oliveType: '',
        harvestMethod: 'manual',
        notes: '',
      });
      
      if (onSuccess) {
        onSuccess();
      }
      
      // Reset success message after 3 seconds
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      setError('Failed to add batch to the blockchain');
    }
  };

  // Only farmers should be able to add new batches
  if (user?.role !== 'farmer') {
    return (
      <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded">
        <div className="flex">
          <div>
            <p className="text-amber-700">
              Only farmers can register new olive batches.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Register New Olive Batch</h2>
      
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4 rounded">
          <div className="flex">
            <div>
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4 rounded">
          <div className="flex">
            <div>
              <p className="text-green-700">Batch successfully registered on the blockchain!</p>
            </div>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="mb-4">
            <label htmlFor="batchId" className="block text-sm font-medium text-gray-700 mb-1">
              Batch ID*
            </label>
            <input
              type="text"
              id="batchId"
              name="batchId"
              value={formData.batchId}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
              placeholder="BATCH-001"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="origin" className="block text-sm font-medium text-gray-700 mb-1">
              Origin Location*
            </label>
            <input
              type="text"
              id="origin"
              name="origin"
              value={formData.origin}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
              placeholder="Andalusia, Spain"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="harvestDate" className="block text-sm font-medium text-gray-700 mb-1">
              Harvest Date*
            </label>
            <input
              type="date"
              id="harvestDate"
              name="harvestDate"
              value={formData.harvestDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="oliveType" className="block text-sm font-medium text-gray-700 mb-1">
              Olive Type
            </label>
            <input
              type="text"
              id="oliveType"
              name="oliveType"
              value={formData.oliveType}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
              placeholder="Picual, Arbequina, etc."
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="harvestMethod" className="block text-sm font-medium text-gray-700 mb-1">
              Harvest Method
            </label>
            <select
              id="harvestMethod"
              name="harvestMethod"
              value={formData.harvestMethod}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
            >
              <option value="manual">Manual Harvesting</option>
              <option value="mechanical">Mechanical Harvesting</option>
              <option value="mixed">Mixed Methods</option>
            </select>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
            Additional Notes
          </label>
          <textarea
            id="notes"
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-olive-500 focus:border-olive-500"
            placeholder="Weather conditions, grove details, etc."
          ></textarea>
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-olive-600 text-white rounded-md hover:bg-olive-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </span>
            ) : 'Register Batch'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BatchForm;