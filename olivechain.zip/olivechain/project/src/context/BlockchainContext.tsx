import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import db from '../../db.json'; // Using relative path

// Define the batch status types
export type BatchStatus = 'HARVESTED' | 'PRESSED' | 'BOTTLED' | 'QUALITY_CHECKED' | 'DISTRIBUTED' | 'RETAIL';

// Define stage-specific data interfaces
interface HarvestData {
  harvestMethod: string;
  oliveType: string;
  quantity: number;
  temperature: number;
  humidity: number;
  notes?: string;
}

interface PressingData {
  millDate: string;
  millLocation: string;
  extractionMethod: string;
  temperature: number;
  pressure: number;
  yield: number;
  notes?: string;
}

interface BottlingData {
  bottleDate: string;
  bottleLocation: string;
  bottleType: string;
  volume: number;
  batchNumber: string;
  notes?: string;
}

interface QualityData {
  acidity: number;
  peroxides: number;
  polyphenols: number;
  rating: number;
  organolepticNotes?: string;
  certification?: string;
}

interface DistributionData {
  distributor: string;
  distributionDate: string;
  storageConditions: string;
  transportMethod: string;
  destination: string;
  notes?: string;
}

interface RetailData {
  retailer: string;
  retailDate: string;
  location: string;
  price: number;
  notes?: string;
}

// Define the olive batch interface
export interface OliveBatch {
  id?: string;
  batchId: string;
  origin: string;
  harvestDate: string;
  state: BatchStatus;
  history: {
    state: BatchStatus;
    timestamp: string;
    data?: HarvestData | PressingData | BottlingData | QualityData | DistributionData | RetailData;
  }[];
  // Stage-specific data
  harvest?: HarvestData;
  pressing?: PressingData;
  bottling?: BottlingData;
  quality?: QualityData;
  distribution?: DistributionData;
  retail?: RetailData;
  // Legacy fields for backward compatibility
  millDate?: string;
  bottleDate?: string;
  distributor?: string;
  retailer?: string;
}

// Define the context type
interface BlockchainContextType {
  batches: OliveBatch[];
  loading: boolean;
  error: string | null;
  addBatch: (batch: Omit<OliveBatch, 'history' | 'state'>) => Promise<void>;
  updateBatchStatus: (batchId: string, newStatus: BatchStatus, additionalData?: any) => Promise<void>;
  getBatch: (batchId: string) => OliveBatch | undefined;
  getAllBatches: () => Promise<void>;
}

// Create the context
const BlockchainContext = createContext<BlockchainContextType>({
  batches: [],
  loading: false,
  error: null,
  addBatch: async () => {},
  updateBatchStatus: async () => {},
  getBatch: () => undefined,
  getAllBatches: async () => {},
});

// Provider props
interface BlockchainProviderProps {
  children: ReactNode;
}

// Helper function to save batches to localStorage
const saveBatchesToStorage = (batches: OliveBatch[]) => {
  try {
    localStorage.setItem('olivechain_batches', JSON.stringify(batches));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
    throw new Error('Failed to save batch data');
  }
};

// Helper function to load batches from localStorage
const loadBatchesFromStorage = (): OliveBatch[] => {
  try {
    const stored = localStorage.getItem('olivechain_batches');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return [];
  }
};

// BlockchainProvider component
export const BlockchainProvider = ({ children }: BlockchainProviderProps) => {
  const [batches, setBatches] = useState<OliveBatch[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Validate stage transition and data
  const validateStageTransition = (currentStage: BatchStatus, nextStage: BatchStatus, data: any) => {
    // Validate stage order
    const stages: BatchStatus[] = ['HARVESTED', 'PRESSED', 'BOTTLED', 'QUALITY_CHECKED', 'DISTRIBUTED', 'RETAIL'];
    const currentIndex = stages.indexOf(currentStage);
    const nextIndex = stages.indexOf(nextStage);
    
    if (nextIndex !== currentIndex + 1) {
      throw new Error(`Invalid stage transition from ${currentStage} to ${nextStage}`);
    }

    // Validate stage-specific data
    switch (nextStage) {
      case 'HARVESTED':
        if (!data.harvestMethod) throw new Error('Harvest method is required');
        if (!data.oliveType) throw new Error('Olive type is required');
        if (!data.quantity || data.quantity <= 0) throw new Error('Valid quantity is required');
        if (!data.temperature) throw new Error('Temperature is required');
        if (!data.humidity) throw new Error('Humidity is required');
        break;

      case 'PRESSED':
        if (!data.millDate) throw new Error('Mill date is required');
        if (!data.millLocation) throw new Error('Mill location is required');
        if (!data.extractionMethod) throw new Error('Extraction method is required');
        if (!data.temperature) throw new Error('Temperature is required');
        if (!data.pressure) throw new Error('Pressure is required');
        if (!data.yield || data.yield <= 0) throw new Error('Valid yield is required');
        break;

      case 'BOTTLED':
        if (!data.bottleDate) throw new Error('Bottle date is required');
        if (!data.bottleLocation) throw new Error('Bottle location is required');
        if (!data.bottleType) throw new Error('Bottle type is required');
        if (!data.volume || data.volume <= 0) throw new Error('Valid volume is required');
        if (!data.batchNumber) throw new Error('Batch number is required');
        break;

      case 'QUALITY_CHECKED':
        if (!data.quality) throw new Error('Quality data is required');
        if (data.quality.acidity < 0 || data.quality.acidity > 100) throw new Error('Invalid acidity value');
        if (data.quality.peroxides < 0) throw new Error('Invalid peroxides value');
        if (data.quality.polyphenols < 0) throw new Error('Invalid polyphenols value');
        if (data.quality.rating < 0 || data.quality.rating > 5) throw new Error('Invalid rating value');
        break;

      case 'DISTRIBUTED':
        if (!data.distributor) throw new Error('Distributor information is required');
        if (!data.distributionDate) throw new Error('Distribution date is required');
        if (!data.storageConditions) throw new Error('Storage conditions are required');
        if (!data.transportMethod) throw new Error('Transport method is required');
        if (!data.destination) throw new Error('Destination is required');
        break;

      case 'RETAIL':
        if (!data.retailer) throw new Error('Retailer information is required');
        if (!data.retailDate) throw new Error('Retail date is required');
        if (!data.location) throw new Error('Location is required');
        if (!data.price || data.price <= 0) throw new Error('Valid price is required');
        break;
    }
  };

  // Load batches
  const getAllBatches = async () => {
    setLoading(true);
    try {
      // First try to load from localStorage
      const storedBatches = loadBatchesFromStorage();
      
      if (storedBatches.length > 0) {
        setBatches(storedBatches);
      } else {
        // If no stored batches, use the initial data from db.json
        const data = db.batches as OliveBatch[];
        setBatches(data);
        saveBatchesToStorage(data);
      }
      setLoading(false);
    } catch (err) {
      console.error('Error loading batches:', err);
      setError('Failed to load batches');
      setLoading(false);
    }
  };

  // Add new batch
  const addBatch = async (batchData: Omit<OliveBatch, 'history' | 'state'>) => {
    setLoading(true);
    try {
      const newBatch: OliveBatch = {
        ...batchData,
        state: 'HARVESTED',
        history: [
          {
            state: 'HARVESTED',
            timestamp: new Date().toISOString(),
          },
        ],
      };
      
      const updatedBatches = [...batches, newBatch];
      saveBatchesToStorage(updatedBatches);
      setBatches(updatedBatches);
      setLoading(false);
    } catch (err) {
      console.error('Error adding batch:', err);
      setError('Failed to add batch');
      setLoading(false);
      throw err;
    }
  };

  // Update batch status
  const updateBatchStatus = async (batchId: string, newStatus: BatchStatus, additionalData: any = {}) => {
    setLoading(true);
    try {
      // Find the batch
      const batch = batches.find(b => b.batchId === batchId);
      if (!batch) {
        throw new Error(`Batch ${batchId} not found`);
      }

      // Validate the transition
      validateStageTransition(batch.state, newStatus, additionalData);

      // Create history entry with enhanced data
      const historyEntry = {
        state: newStatus,
        timestamp: new Date().toISOString(),
        data: additionalData
      };

      // Update batches
      const updatedBatches = batches.map(batch =>
        batch.batchId === batchId
          ? {
              ...batch,
              ...additionalData,
              state: newStatus,
              history: [...(batch.history || []), historyEntry],
            }
          : batch
      );

      // Save to storage and update state
      saveBatchesToStorage(updatedBatches);
      setBatches(updatedBatches);
      setLoading(false);
    } catch (err) {
      console.error('Error updating batch status:', err);
      setError('Failed to update batch status');
      setLoading(false);
      throw err;
    }
  };

  // Get single batch
  const getBatch = (batchId: string) => {
    return batches.find((batch) => batch.batchId === batchId);
  };

  // Load batches on mount
  useEffect(() => {
    getAllBatches();
  }, []);

  return (
    <BlockchainContext.Provider
      value={{
        batches,
        loading,
        error,
        addBatch,
        updateBatchStatus,
        getBatch,
        getAllBatches,
      }}
    >
      {children}
    </BlockchainContext.Provider>
  );
};

// Hook for consumers
export const useBlockchain = () => useContext(BlockchainContext);
