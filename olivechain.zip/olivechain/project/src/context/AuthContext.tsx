import React, { createContext, useContext, useState, ReactNode } from 'react';

// Define user roles available in the system
export type UserRole = 'farmer' | 'mill' | 'qualityControl' | 'distributor' | 'retailer';

// Define the user interface
export interface User {
  id: string;
  name: string;
  role: UserRole;
  organization: string;
}

// Define the auth context state
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

// Create the Auth Context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: () => {},
  logout: () => {},
});

// Define props for the AuthProvider component
interface AuthProviderProps {
  children: ReactNode;
}

// Create a provider component for the Auth Context
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);

  const login = (userData: User) => {
    setUser(userData);
    // In a real app, you would store the user in localStorage or a secure cookie
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  // Provide the auth context to child components
  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Create a custom hook for using the Auth Context
export const useAuth = () => useContext(AuthContext);