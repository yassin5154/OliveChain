// Supply chain stages in order
export const SUPPLY_CHAIN_STAGES = [
  {
    id: 'HARVESTED',
    label: 'Harvested',
    description: 'Olives are harvested from the grove',
    color: 'bg-lime-500',
    icon: 'Leaf',
    role: 'farmer'
  },
  {
    id: 'PRESSED',
    label: 'Pressed',
    description: 'Olives are pressed into oil at the mill',
    color: 'bg-yellow-600',
    icon: 'Factory',
    role: 'mill'
  },
  {
    id: 'BOTTLED',
    label: 'Bottled',
    description: 'Oil is filtered and bottled',
    color: 'bg-amber-500',
    icon: 'Flask',
    role: 'mill'
  },
  {
    id: 'QUALITY_CHECKED',
    label: 'Quality Checked',
    description: 'Quality control tests performed',
    color: 'bg-blue-500',
    icon: 'ClipboardCheck',
    role: 'qualityControl'
  },
  {
    id: 'DISTRIBUTED',
    label: 'Distributed',
    description: 'Oil is distributed to retailers',
    color: 'bg-purple-500',
    icon: 'Truck',
    role: 'distributor'
  },
  {
    id: 'RETAIL',
    label: 'Retail',
    description: 'Oil is available for purchase',
    color: 'bg-green-600',
    icon: 'Store',
    role: 'retailer'
  }
];

// Organization types
export const ORGANIZATIONS = [
  {
    id: 'FarmerOrgMSP',
    name: 'Farmer Organization',
    role: 'farmer',
    color: 'bg-lime-700',
  },
  {
    id: 'MillOrgMSP',
    name: 'Mill Organization',
    role: 'mill',
    color: 'bg-amber-700',
  },
  {
    id: 'QCOrgMSP',
    name: 'Quality Control Organization',
    role: 'qualityControl',
    color: 'bg-blue-700',
  },
  {
    id: 'DistributorOrgMSP',
    name: 'Distributor Organization',
    role: 'distributor',
    color: 'bg-purple-700',
  },
  {
    id: 'RetailerOrgMSP',
    name: 'Retailer Organization',
    role: 'retailer',
    color: 'bg-green-700',
  }
];

// Quality rating guidelines
export const QUALITY_RATINGS = {
  acidity: {
    excellent: { max: 0.3, label: 'Extra Virgin' },
    good: { max: 0.8, label: 'Virgin' },
    standard: { max: 2.0, label: 'Lampante' },
  },
  peroxides: {
    excellent: { max: 10, unit: 'meq O2/kg' },
    good: { max: 15, unit: 'meq O2/kg' },
    standard: { max: 20, unit: 'meq O2/kg' },
  },
  polyphenols: {
    low: { min: 50, max: 150, unit: 'mg/kg' },
    medium: { min: 151, max: 250, unit: 'mg/kg' },
    high: { min: 251, max: 500, unit: 'mg/kg' },
  }
};

// Mock user data
export const MOCK_USERS = [
  {
    id: 'farmer1',
    name: 'Maria Olivera',
    role: 'farmer',
    organization: 'FarmerOrgMSP',
    email: 'maria@olivegroves.com',
    password: 'password123', // In a real app, passwords would be securely hashed
  },
  {
    id: 'mill1',
    name: 'Antonio Pressori',
    role: 'mill',
    organization: 'MillOrgMSP',
    email: 'antonio@olivemills.com',
    password: 'password123',
  },
  {
    id: 'qc1',
    name: 'Elena Qualiti',
    role: 'qualityControl',
    organization: 'QCOrgMSP',
    email: 'elena@olivequality.com',
    password: 'password123',
  },
  {
    id: 'distributor1',
    name: 'Carlos Delivery',
    role: 'distributor',
    organization: 'DistributorOrgMSP',
    email: 'carlos@olivedistribution.com',
    password: 'password123',
  },
  {
    id: 'retailer1',
    name: 'Sophie Sales',
    role: 'retailer',
    organization: 'RetailerOrgMSP',
    email: 'sophie@olivesales.com',
    password: 'password123',
  },
];