// Types related to Hyperledger Fabric
export interface FabricPeer {
  name: string;
  url: string;
  organization: string;
}

export interface FabricOrganization {
  id: string;
  name: string;
  mspId: string;
  peers: FabricPeer[];
}

export interface FabricChannel {
  name: string;
  organizations: string[];
}

export interface NetworkConfig {
  organizations: FabricOrganization[];
  channels: FabricChannel[];
}

// Event types for supply chain tracking
export interface BatchEvent {
  batchId: string;
  eventType: string;
  timestamp: string;
  data: Record<string, any>;
}

// User related types
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  organization: string;
  permissions: string[];
}

// Quality metrics
export interface QualityMetrics {
  acidity: number;        // % oleic acid
  peroxides: number;      // mEq O2/kg
  polyphenols: number;    // mg/kg
  rating: number;         // Overall quality rating (0-5)
}