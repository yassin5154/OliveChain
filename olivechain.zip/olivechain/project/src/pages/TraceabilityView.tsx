import React, { useState, useEffect } from 'react';
import { Search, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useBlockchain } from '../context/BlockchainContext';
import QRCodeGenerator from '../components/common/QRCodeGenerator';
import SupplyChainFlow from '../components/common/SupplyChainFlow';

const TraceabilityView: React.FC = () => {
  const navigate = useNavigate();
  const { batches } = useBlockchain();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedBatch, setSearchedBatch] = useState<string | null>(null);
  
  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    setSearchedBatch(searchQuery.trim());
  };
  
  const batch = batches.find(b => b.batchId.toLowerCase() === searchedBatch?.toLowerCase());
  
  // Debug: Log all batch IDs and their types
  useEffect(() => {
    console.log('All batch IDs:', batches.map(b => ({ id: b.batchId, type: typeof b.batchId })));
  }, [batches]);
  
  return (
    <div className="min-h-screen bg-gray-50 pt-16 px-4 pb-16">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Traceability</h1>
          <p className="text-gray-600">Search for a batch to view its complete supply chain journey</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
            <div className="flex-1">
              <label htmlFor="batchSearch" className="block text-sm font-medium text-gray-700 mb-1">
                Batch ID
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="batchSearch"
                  placeholder="Enter batch ID (e.g., BATCH-001)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500 py-2 px-3"
                />
              </div>
            </div>
            
            <button
              onClick={handleSearch}
              className="px-4 py-2 bg-olive-600 text-white rounded-md hover:bg-olive-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500"
            >
              Search
            </button>
          </div>
          
          <div className="mt-4 text-sm text-gray-500">
            <p>Enter a batch ID to view its complete journey through the supply chain.</p>
          </div>
        </div>
        
        {searchedBatch && !batch && (
          <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded">
            <div className="flex">
              <div>
                <p className="text-amber-700">
                  No batch found with ID: <strong>{searchedBatch}</strong>
                </p>
              </div>
            </div>
          </div>
        )}
        
        {batch && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-800">{batch.batchId}</h2>
                    <p className="text-gray-600">{batch.origin}</p>
                  </div>
                  <button
                    onClick={() => navigate(`/batches/${batch.batchId}`)}
                    className="inline-flex items-center px-3 py-1 text-sm text-olive-700 hover:text-olive-800"
                  >
                    View Details
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </button>
                </div>
                <div className="mb-8">
                  <SupplyChainFlow batch={batch} />
                </div>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium text-gray-800 mb-3">Supply Chain Timeline</h3>
                    <div className="space-y-4">
                      {batch.history.map((event, index) => {
                        const isLast = index === batch.history.length - 1;
                        return (
                          <div key={index} className="relative">
                            {!isLast && (
                              <div className="absolute top-5 bottom-0 left-2.5 w-0.5 bg-gray-200"></div>
                            )}
                            <div className="relative flex items-start space-x-3">
                              <div>
                                <div className="relative px-1">
                                  <div className="h-5 w-5 rounded-full bg-olive-600 flex items-center justify-center ring-4 ring-white">
                                    <div className="h-2 w-2 rounded-full bg-white"></div>
                                  </div>
                                </div>
                              </div>
                              <div className="min-w-0 flex-1 py-0">
                                <div className="text-sm text-gray-500">
                                  <div className="font-medium text-gray-900">
                                    {event.state.split('_').map(word => word.charAt(0) + word.slice(1).toLowerCase()).join(' ')}
                                  </div>
                                  <div className="mt-0.5">
                                    {new Date(event.timestamp).toLocaleString()}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  {batch.quality && (
                    <div>
                      <h3 className="text-lg font-medium text-gray-800 mb-3">Quality Assessment</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-gray-50 p-3 rounded-md">
                          <div className="text-sm text-gray-500">Acidity</div>
                          <div className="text-lg font-medium text-gray-900">{batch.quality.acidity}%</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md">
                          <div className="text-sm text-gray-500">Peroxides</div>
                          <div className="text-lg font-medium text-gray-900">{batch.quality.peroxides} meq O2/kg</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md">
                          <div className="text-sm text-gray-500">Polyphenols</div>
                          <div className="text-lg font-medium text-gray-900">{batch.quality.polyphenols} mg/kg</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md">
                          <div className="text-sm text-gray-500">Quality Rating</div>
                          <div className="text-lg font-medium text-gray-900">
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <span key={i} className={`h-4 w-4 ${i < Math.round(batch.quality.rating) ? 'text-yellow-400' : 'text-gray-300'}`}>★</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-medium text-gray-800 mb-4">Verify Authenticity</h3>
                <div className="flex flex-col items-center mb-4">
                  <QRCodeGenerator data={`${window.location.origin}/#/verify/${batch.batchId}`} />
                  <a
                    href={`#/verify/${batch.batchId}`}
                    className="text-olive-600 hover:text-olive-800 text-sm break-all underline mt-2"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {window.location.origin + '/#/verify/' + batch.batchId}
                  </a>
                </div>
                <p className="text-sm text-gray-600 text-center mb-4">
                  Scan this QR code to verify this batch's authenticity on the blockchain.
                </p>
                <div className="bg-olive-50 p-4 rounded-md">
                  <h4 className="text-sm font-medium text-olive-800 mb-2">Blockchain Verification</h4>
                  <p className="text-xs text-olive-700">
                    This batch information is stored on a secure blockchain, ensuring data integrity and preventing tampering.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TraceabilityView;