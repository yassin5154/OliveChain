import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, BarChart2, TrendingUp, Database } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBlockchain } from '../context/BlockchainContext';
import BatchCard from '../components/common/BatchCard';
import BatchForm from '../components/batch/BatchForm';
import { SUPPLY_CHAIN_STAGES } from '../utils/constants';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { batches, getAllBatches, loading } = useBlockchain();
  
  const [showForm, setShowForm] = useState(false);
  
  useEffect(() => {
    getAllBatches();
  }, []);
  
  // Filter batches based on user role
  const filteredBatches = user 
    ? batches.filter(batch => {
        const currentStageIndex = SUPPLY_CHAIN_STAGES.findIndex(stage => stage.id === batch.state);
        const relevantStage = SUPPLY_CHAIN_STAGES.find(stage => stage.role === user.role);
        
        if (relevantStage) {
          const relevantStageIndex = SUPPLY_CHAIN_STAGES.findIndex(stage => stage.id === relevantStage.id);
          
          // Show batches that are at or before this user's stage
          return currentStageIndex <= relevantStageIndex;
        }
        
        return false;
      })
    : [];

  // Get statistics for the dashboard
  const getStats = () => {
    if (batches.length === 0) return null;
    
    const stats = {
      totalBatches: batches.length,
      yourBatches: filteredBatches.length,
      stageStats: SUPPLY_CHAIN_STAGES.reduce((acc, stage) => {
        acc[stage.id] = batches.filter(b => b.state === stage.id).length;
        return acc;
      }, {} as Record<string, number>),
    };
    
    return stats;
  };
  
  const stats = getStats();
  
  // Get the appropriate action text based on user role
  const getActionText = () => {
    if (!user) return '';
    
    switch (user.role) {
      case 'farmer':
        return 'Register New Batch';
      case 'mill':
        return 'Process Pending Batches';
      case 'qualityControl':
        return 'Verify Quality';
      case 'distributor':
        return 'Distribute Batches';
      case 'retailer':
        return 'Confirm Receipt';
      default:
        return 'View Batches';
    }
  };
  
  if (!user) {
    navigate('/login');
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 pt-16 px-4 pb-16">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user.name}</p>
        </div>
        
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-gray-700">Total Batches</h3>
                <Database className="h-5 w-5 text-olive-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats.totalBatches}</p>
              <p className="text-sm text-gray-500 mt-1">Registered in the system</p>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-gray-700">Your Batches</h3>
                <TrendingUp className="h-5 w-5 text-olive-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900">{stats.yourBatches}</p>
              <p className="text-sm text-gray-500 mt-1">Awaiting your action</p>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-gray-700">Process Stage</h3>
                <BarChart2 className="h-5 w-5 text-olive-600" />
              </div>
              <div className="mt-3">
                {SUPPLY_CHAIN_STAGES.map((stage) => (
                  <div key={stage.id} className="flex items-center mt-2">
                    <div className={`h-2 w-2 rounded-full ${stage.color} mr-2`}></div>
                    <div className="text-xs text-gray-600 w-24">{stage.label}</div>
                    <div className="flex-1">
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full ${stage.color}`}
                          style={{ width: `${(stats.stageStats[stage.id] / stats.totalBatches) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="ml-2 text-xs font-medium text-gray-700">{stats.stageStats[stage.id]}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Your Batches</h2>
          {user.role === 'farmer' && (
            <button
              onClick={() => setShowForm(!showForm)}
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-olive-600 hover:bg-olive-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500"
            >
              <PlusCircle className="h-4 w-4 mr-1" />
              Register New Batch
            </button>
          )}
        </div>
        
        {showForm && (
          <div className="mb-8">
            <BatchForm onSuccess={() => setShowForm(false)} />
          </div>
        )}
        
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-olive-700"></div>
          </div>
        ) : filteredBatches.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBatches.map((batch) => (
              <BatchCard key={batch.batchId} batch={batch} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-600 mb-4">No batches found that require your attention.</p>
            {user.role === 'farmer' && (
              <button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-olive-700 bg-olive-100 hover:bg-olive-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500"
              >
                <PlusCircle className="h-5 w-5 mr-2" />
                {getActionText()}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;