import React, { useEffect, useState } from 'react';
import { Search, Filter, PlusCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBlockchain } from '../context/BlockchainContext';
import BatchCard from '../components/common/BatchCard';
import BatchForm from '../components/batch/BatchForm';
import { SUPPLY_CHAIN_STAGES } from '../utils/constants';

const BatchManagement: React.FC = () => {
  const { user } = useAuth();
  const { batches, getAllBatches, loading } = useBlockchain();
  
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  
  useEffect(() => {
    getAllBatches();
  }, []);
  
  // Filter batches based on search query and status filter
  const filteredBatches = batches.filter(batch => {
    // Apply search filter
    const matchesSearch = 
      searchQuery === '' || 
      batch.batchId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      batch.origin.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Apply status filter
    const matchesStatus = filterStatus === null || batch.state === filterStatus;
    
    return matchesSearch && matchesStatus;
  });
  
  // Filter options from available stages
  const filterOptions = SUPPLY_CHAIN_STAGES.map(stage => ({
    value: stage.id,
    label: stage.label,
    color: stage.color
  }));
  
  // Count batches by status
  const batchCountByStatus = SUPPLY_CHAIN_STAGES.reduce((acc, stage) => {
    acc[stage.id] = batches.filter(b => b.state === stage.id).length;
    return acc;
  }, {} as Record<string, number>);
  
  return (
    <div className="min-h-screen bg-gray-50 pt-16 px-4 pb-16">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Batch Management</h1>
          <p className="text-gray-600">Track and manage olive oil batches throughout the supply chain</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-800 mb-4 md:mb-0">Batch Status Overview</h2>
            {user?.role === 'farmer' && (
              <button
                onClick={() => setShowForm(!showForm)}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-olive-600 hover:bg-olive-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-olive-500"
              >
                <PlusCircle className="h-4 w-4 mr-1" />
                Register New Batch
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {SUPPLY_CHAIN_STAGES.map((stage) => (
              <button
                key={stage.id}
                onClick={() => setFilterStatus(filterStatus === stage.id ? null : stage.id)}
                className={`flex flex-col items-center p-3 rounded-lg border transition-colors ${
                  filterStatus === stage.id
                    ? `${stage.color.replace('bg-', 'bg-opacity-20 border-')} border-${stage.color.replace('bg-', '')}`
                    : 'border-gray-200 hover:border-gray-300 bg-white'
                }`}
              >
                
                <span className="text-sm font-medium text-gray-700">{stage.label}</span>
                <span className="text-xs text-gray-500 mt-1">{batchCountByStatus[stage.id] || 0} batches</span>
              </button>
            ))}
          </div>
        </div>
        
        {showForm && (
          <div className="mb-8">
            <BatchForm onSuccess={() => setShowForm(false)} />
          </div>
        )}
        
        <div className="mb-6">
          <div className="bg-white rounded-lg shadow-md p-4">
            <div className="flex flex-col md:flex-row justify-between space-y-4 md:space-y-0 md:space-x-4">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search by batch ID or origin..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500 py-2 px-3"
                />
              </div>
              
              <div className="flex space-x-2">
                <div className="relative inline-block">
                  <select
                    value={filterStatus || ''}
                    onChange={(e) => setFilterStatus(e.target.value || null)}
                    className="appearance-none pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-olive-500 focus:border-olive-500"
                  >
                    <option value="">All Statuses</option>
                    {filterOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Filter className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
                
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setFilterStatus(null);
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-olive-700"></div>
          </div>
        ) : filteredBatches.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBatches.map((batch) => (
              <BatchCard key={batch.batchId} batch={batch} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-600">
              {searchQuery || filterStatus
                ? 'No batches match your search criteria. Try adjusting your filters.'
                : 'No batches found in the system.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BatchManagement;