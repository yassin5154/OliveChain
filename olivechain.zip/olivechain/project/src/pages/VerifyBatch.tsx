import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const VerifyBatch: React.FC = () => {
  const { batchId } = useParams<{ batchId: string }>();
  const [batch, setBatch] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    try {
      const stored = localStorage.getItem('olivechain_batches');
      if (stored) {
        const batches = JSON.parse(stored);
        const found = batches.find((b: any) => (b.batchId || '').toLowerCase() === (batchId || '').toLowerCase());
        if (found) {
          setBatch(found);
        } else {
          setError('Batch not found or verification code is invalid');
        }
      } else {
        setError('No batch data found.');
      }
    } catch (err) {
      setError('Error verifying batch. Please try again later.');
      console.error('Error verifying batch:', err);
    } finally {
      setLoading(false);
    }
  }, [batchId]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-olive-50">
        <div className="text-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-olive-700 mx-auto mb-4"></div>
          <p className="text-olive-800 text-lg">Verifying batch information...</p>
        </div>
      </div>
    );
  }

  if (error || !batch) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-olive-50">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-4">
              <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Verification Failed</h2>
            <p className="text-gray-600 mb-6">{error || 'Unable to verify this batch'}</p>
            <Link 
              to="/" 
              className="inline-block px-6 py-3 bg-olive-600 text-white rounded-md hover:bg-olive-700 transition-colors"
            >
              Return to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-olive-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white shadow-lg rounded-lg overflow-hidden">
          <div className="bg-olive-600 px-6 py-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Batch Verification</h2>
              <div className="bg-white text-olive-700 px-3 py-1 rounded-full text-sm font-semibold">
                {batch.state}
              </div>
            </div>
          </div>
          
          <div className="p-6">
            {/* QR Code and direct link */}
            <div className="flex flex-col items-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 mb-4">
                <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
              </div>
              {/* QR code and link */}
              <div className="mb-2">
                <p className="text-sm text-gray-600 mb-1">Scan or click the link below to verify this batch:</p>
                <div className="flex flex-col items-center">
                  {/* You can replace this with your QRCodeGenerator if you want a real QR code */}
                  <a
                    href={`#/verify/${batch.batchId}`}
                    className="text-olive-600 hover:text-olive-800 text-sm break-all underline mb-2"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {window.location.origin + '/#/verify/' + batch.batchId}
                  </a>
                </div>
              </div>
            </div>
            
            <div className="text-center mb-8">
              <h3 className="text-xl font-semibold text-gray-800 mb-1">Authentication Successful</h3>
              <p className="text-gray-600">This is a genuine batch recorded on the blockchain</p>
            </div>
            
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-lg font-medium text-gray-800 mb-4">Batch Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded">
                  <p className="text-sm text-gray-500">Batch ID</p>
                  <p className="font-medium text-gray-800">{batch.batchId}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded">
                  <p className="text-sm text-gray-500">Origin</p>
                  <p className="font-medium text-gray-800">{batch.origin}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded">
                  <p className="text-sm text-gray-500">Harvest Date</p>
                  <p className="font-medium text-gray-800">{new Date(batch.harvestDate).toLocaleDateString()}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded">
                  <p className="text-sm text-gray-500">Current Status</p>
                  <p className="font-medium text-gray-800">{batch.state}</p>
                </div>
              </div>
            </div>

            {/* Harvest Details */}
            <div className="mt-6">
              <h4 className="text-md font-semibold text-olive-700 mb-2">Harvest Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><span className="text-sm text-gray-500">Olive Type:</span> <span className="font-medium">{batch.oliveType || 'N/A'}</span></div>
                <div><span className="text-sm text-gray-500">Harvest Method:</span> <span className="font-medium">{batch.harvestMethod || 'N/A'}</span></div>
                <div><span className="text-sm text-gray-500">Notes:</span> <span className="font-medium">{batch.notes || 'N/A'}</span></div>
              </div>
            </div>

            {/* Pressing Details */}
            {batch.millDate && (
              <div className="mt-6">
                <h4 className="text-md font-semibold text-olive-700 mb-2">Pressing Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><span className="text-sm text-gray-500">Mill Date:</span> <span className="font-medium">{new Date(batch.millDate).toLocaleDateString()}</span></div>
                  <div><span className="text-sm text-gray-500">Mill Location:</span> <span className="font-medium">{batch.millLocation || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Extraction Method:</span> <span className="font-medium">{batch.extractionMethod || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Temperature:</span> <span className="font-medium">{batch.temperature || 'N/A'} °C</span></div>
                  <div><span className="text-sm text-gray-500">Pressure:</span> <span className="font-medium">{batch.pressure || 'N/A'} bar</span></div>
                  <div><span className="text-sm text-gray-500">Yield:</span> <span className="font-medium">{batch.yield || 'N/A'} %</span></div>
                  <div><span className="text-sm text-gray-500">Notes:</span> <span className="font-medium">{batch.pressingNotes || batch.notes || 'N/A'}</span></div>
                </div>
              </div>
            )}

            {/* Bottling Details */}
            {batch.bottleDate && (
              <div className="mt-6">
                <h4 className="text-md font-semibold text-olive-700 mb-2">Bottling Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><span className="text-sm text-gray-500">Bottle Date:</span> <span className="font-medium">{new Date(batch.bottleDate).toLocaleDateString()}</span></div>
                  <div><span className="text-sm text-gray-500">Bottle Location:</span> <span className="font-medium">{batch.bottleLocation || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Bottle Type:</span> <span className="font-medium">{batch.bottleType || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Volume:</span> <span className="font-medium">{batch.volume || 'N/A'} ml</span></div>
                  <div><span className="text-sm text-gray-500">Batch Number:</span> <span className="font-medium">{batch.batchNumber || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Notes:</span> <span className="font-medium">{batch.bottlingNotes || batch.notes || 'N/A'}</span></div>
                </div>
              </div>
            )}

            {/* Quality Details */}
            {batch.quality && (
              <div className="mt-6">
                <h4 className="text-md font-semibold text-olive-700 mb-2">Quality Assessment</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><span className="text-sm text-gray-500">Acidity:</span> <span className="font-medium">{batch.quality.acidity}%</span></div>
                  <div><span className="text-sm text-gray-500">Peroxides:</span> <span className="font-medium">{batch.quality.peroxides} meq O2/kg</span></div>
                  <div><span className="text-sm text-gray-500">Polyphenols:</span> <span className="font-medium">{batch.quality.polyphenols} mg/kg</span></div>
                  <div><span className="text-sm text-gray-500">Quality Rating:</span> <span className="font-medium">{batch.quality.rating}/5</span></div>
                </div>
              </div>
            )}

            {/* Distribution Details */}
            {batch.distributor && (
              <div className="mt-6">
                <h4 className="text-md font-semibold text-olive-700 mb-2">Distribution Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><span className="text-sm text-gray-500">Distributor:</span> <span className="font-medium">{batch.distributor}</span></div>
                  <div><span className="text-sm text-gray-500">Distribution Date:</span> <span className="font-medium">{batch.distributionDate ? new Date(batch.distributionDate).toLocaleDateString() : 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Storage Conditions:</span> <span className="font-medium">{batch.storageConditions || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Transport Method:</span> <span className="font-medium">{batch.transportMethod || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Destination:</span> <span className="font-medium">{batch.destination || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Notes:</span> <span className="font-medium">{batch.distributionNotes || batch.notes || 'N/A'}</span></div>
                </div>
              </div>
            )}

            {/* Retail Details */}
            {batch.retailer && (
              <div className="mt-6">
                <h4 className="text-md font-semibold text-olive-700 mb-2">Retail Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><span className="text-sm text-gray-500">Retailer:</span> <span className="font-medium">{batch.retailer}</span></div>
                  <div><span className="text-sm text-gray-500">Retail Date:</span> <span className="font-medium">{batch.retailDate ? new Date(batch.retailDate).toLocaleDateString() : 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Location:</span> <span className="font-medium">{batch.location || 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Price:</span> <span className="font-medium">{batch.price ? `${batch.price} DH` : 'N/A'}</span></div>
                  <div><span className="text-sm text-gray-500">Notes:</span> <span className="font-medium">{batch.retailNotes || batch.notes || 'N/A'}</span></div>
                </div>
              </div>
            )}
          </div>
          
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
            <div className="text-center">
              <Link 
                to="/" 
                className="inline-block px-6 py-3 bg-olive-600 text-white rounded-md hover:bg-olive-700 transition-colors"
              >
                Return to Home
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VerifyBatch; 