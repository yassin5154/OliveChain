import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Leaf, ChevronRight, Shield, BarChart2, Truck, Search, Factory, FlaskRound as Flask, ClipboardCheck, Store } from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-olive-900 to-olive-700 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative z-10 py-16 md:py-28">
            <div className="max-w-3xl">
              <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                <span className="block">Blockchain-Powered</span>
                <span className="block text-olive-200">Olive Oil Traceability</span>
              </h1>
              <p className="mt-6 text-xl text-olive-100 max-w-3xl">
                OliveChain brings transparency and trust to the olive oil supply chain through secure, immutable blockchain technology.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => navigate('/login')}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-olive-600 hover:bg-olive-500 transition-colors"
                >
                  Get Started
                  <ChevronRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => navigate('/trace')}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-olive-800 bg-white hover:bg-gray-50 transition-colors"
                >
                  Verify a Batch
                  <Search className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Decorative olive branch elements */}
        <div className="absolute top-0 right-0 -mt-20 -mr-20 opacity-50">
          <Leaf className="w-64 h-64 text-olive-500 transform rotate-45" />
        </div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 opacity-20">
          <Leaf className="w-48 h-48 text-olive-300 transform -rotate-15" />
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold tracking-wide text-olive-600 uppercase">Features</h2>
            <p className="mt-1 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              End-to-End Supply Chain Visibility
            </p>
            <p className="max-w-2xl mt-5 mx-auto text-xl text-gray-500">
              Track every step of the olive oil journey from farm to table with unmatched transparency and security.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-6 py-8">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-olive-600 rounded-md p-3">
                      <Shield className="h-6 w-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Tamper-Proof Records</h3>
                    </div>
                  </div>
                  <div className="mt-4 text-base text-gray-500">
                    Blockchain technology ensures all supply chain data is immutable and secure, preventing fraud and counterfeiting.
                  </div>
                </div>
              </div>

              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-6 py-8">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-olive-600 rounded-md p-3">
                      <Search className="h-6 w-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Complete Traceability</h3>
                    </div>
                  </div>
                  <div className="mt-4 text-base text-gray-500">
                    Trace any bottle of olive oil back to its source, viewing detailed information at every step of production.
                  </div>
                </div>
              </div>

              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-6 py-8">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-olive-600 rounded-md p-3">
                      <BarChart2 className="h-6 w-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Quality Verification</h3>
                    </div>
                  </div>
                  <div className="mt-4 text-base text-gray-500">
                    Access verified quality metrics for each batch, ensuring you get authentic extra virgin olive oil every time.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Supply Chain Flow */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold tracking-wide text-olive-600 uppercase">The Process</h2>
            <p className="mt-1 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              From Grove to Table
            </p>
            <p className="max-w-2xl mt-5 mx-auto text-xl text-gray-500">
              Follow the journey of premium olive oil through our transparent blockchain system.
            </p>
          </div>

          <div className="mt-16">
            <div className="relative">
              {/* Supply chain flow diagram */}
              <div className="hidden sm:block absolute top-12 inset-0">
                <div className="h-1 bg-gray-200 absolute top-1/2 left-0 right-0 -translate-y-1/2"></div>
              </div>

              <div className="relative grid grid-cols-1 gap-8 sm:grid-cols-3 lg:grid-cols-6">
                {[
                  { icon: Leaf, label: 'Harvested', text: 'Olives harvested from sustainable groves' },
                  { icon: Factory, label: 'Pressed', text: 'Cold-pressed within hours of harvesting' },
                  { icon: Flask, label: 'Bottled', text: 'Filtered and bottled to preserve freshness' },
                  { icon: ClipboardCheck, label: 'Quality Checked', text: 'Tested for purity and quality standards' },
                  { icon: Truck, label: 'Distributed', text: 'Transported under optimal conditions' },
                  { icon: Store, label: 'Retail', text: 'Available with complete traceability information' }
                ].map((step, index) => (
                  <div key={index} className="relative flex flex-col items-center">
                    <div className="bg-olive-600 rounded-full p-3 w-16 h-16 flex items-center justify-center z-10 relative">
                      <step.icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium text-gray-900">{step.label}</h3>
                    <p className="mt-2 text-sm text-gray-500 text-center px-1">{step.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-olive-800">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to get started?</span>
            <span className="block text-olive-300">Join OliveChain today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <button
                onClick={() => navigate('/login')}
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-olive-800 bg-white hover:bg-gray-50 transition-colors"
              >
                Sign In
              </button>
            </div>
            <div className="ml-3 inline-flex rounded-md shadow">
              <button
                onClick={() => navigate('/trace')}
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-olive-600 hover:bg-olive-500 transition-colors"
              >
                Verify Olive Oil
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <Leaf className="h-10 w-10 text-olive-600" />
          </div>
          <div className="mt-8 text-center">
            <p className="text-base text-gray-500">
              &copy; 2025 OliveChain. All rights reserved.
            </p>
          </div>
          <div className="mt-4 flex justify-center space-x-6">
            <a href="#" className="text-gray-400 hover:text-gray-500">
              About
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Contact
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Privacy
            </a>
            <a href="#" className="text-gray-400 hover:text-gray-500">
              Terms
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;