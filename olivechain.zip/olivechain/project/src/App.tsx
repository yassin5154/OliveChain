import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BlockchainProvider, BatchStatus, OliveBatch } from './context/BlockchainContext';
import Navbar from './components/common/Navbar';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import BatchManagement from './pages/BatchManagement';
import BatchDetails from './components/batch/BatchDetails';
import TraceabilityView from './pages/TraceabilityView';
import VerifyBatch from './pages/VerifyBatch';

// Protection wrapper for authenticated routes
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

function AppContent() {
  const { user } = useAuth();

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/batches" 
          element={
            <ProtectedRoute>
              <BatchManagement />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/batches/:batchId" 
          element={
            <ProtectedRoute>
              <BatchDetails />
            </ProtectedRoute>
          } 
        />
        <Route path="/trace" element={<TraceabilityView />} />
        <Route path="/verify/:batchId" element={<VerifyBatch />} />
      </Routes>
    </Router>
  );
}

function App() {
  return (
    <AuthProvider>
      <BlockchainProvider>
        <AppContent />
      </BlockchainProvider>
    </AuthProvider>
  );
}

export default App;